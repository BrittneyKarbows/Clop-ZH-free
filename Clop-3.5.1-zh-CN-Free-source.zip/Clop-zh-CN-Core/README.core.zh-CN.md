# Clop 中文免费版

安装、构建与测试记录见 [中文说明](README.zh-CN.md)。

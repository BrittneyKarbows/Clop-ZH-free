# Clop 中文免费版 3.5.1

Apple Silicon 原生 arm64 版本，基于 FuzzyIdeas/Clop 3.5.0 的公开提交 4be5106951b490c9b61a53f6f15eb580a760bd69。保留上游版权声明及 GPLv3 许可证。

新版取消了试用、Pro 授权、每会话处理次数限制以及批处理的付费门槛。移除了 Paddle、Sparkle 及授权和更新界面。「关于」页直接显示版本。MCP 可免费使用，代理写入和执行脚本仍由用户分别授权。此分支沿用核心版的功能范围，未包含 WarpDrop 安全分享。

已在 macOS 15.8.2 上使用 Xcode 26.3 完成构建。一次应用会话成功处理 逐文件处理的 8 个样例和 12 个批处理样例，并验证关闭 MCP 写入时代理设置请求会被拒绝。应用和 DMG 的完整性检查均已通过。DMG 使用本地临时签名，Apple 公证待完成。

打开 DMG 后，将 Clop 中文拖到「应用程序」。同名升级沿用原版中文版的应用标识和设置。

源码目录下运行 `./Scripts/build-zh-arm64.sh` 即可解析依赖并构建。脚本会下载并校验上游 Git LFS 优化工具资源。产物位于 `build/zh-arm64/Build/Products/Release/Clop.app`，发布前需签名。

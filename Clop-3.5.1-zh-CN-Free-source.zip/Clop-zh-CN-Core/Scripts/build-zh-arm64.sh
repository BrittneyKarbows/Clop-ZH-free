#!/bin/bash
set -euo pipefail

cd "$(dirname "$0")/.."
missing=0
if ! /usr/bin/xcodebuild -version >/dev/null 2>&1; then
    printf '%s\n' '缺少可用的 Xcode。请安装带 macOS 26 SDK 的 Xcode 并完成首次启动。' >&2
    missing=1
fi
if (( missing )); then
    exit 1
fi
if ! /usr/bin/xcrun --sdk macosx --show-sdk-version | /usr/bin/awk -F. '$1 >= 26 { found = 1 } END { exit !found }'; then
    printf '%s\n' '当前 Xcode 未提供 macOS 26 或更高版本的 SDK。' >&2
    exit 1
fi

archive=Clop/bin.tar.lrz
expected="$(cat Clop/bin.tar.lrz.sha256)"
archive_hash() {
    /usr/bin/shasum -a 256 "$1" | /usr/bin/awk '{print $1}'
}
if [[ "$(archive_hash "$archive")" != "$expected" ]]; then
    temp="$(/usr/bin/mktemp Clop/.bin-download.XXXXXX)"
    trap '[[ -z "${temp:-}" ]] || /bin/unlink "$temp"' EXIT
    /usr/bin/curl --fail --location --retry 2 \
        'https://media.githubusercontent.com/media/FuzzyIdeas/Clop/4be5106951b490c9b61a53f6f15eb580a760bd69/Clop/bin.tar.lrz' \
        -o "$temp"
    if [[ "$(archive_hash "$temp")" != "$expected" ]]; then
        printf '%s\n' '压缩工具资源的 SHA-256 校验失败。' >&2
        exit 1
    fi
    /bin/mv -f "$temp" "$archive"
    temp=
fi

derived="$PWD/build/zh-arm64"
project_args=(-project Clop.xcodeproj -scheme Clop -derivedDataPath "$derived")
/usr/bin/xcodebuild "${project_args[@]}" -resolvePackageDependencies

# swift-ignore 0.1.4 ships two module maps for the same macOS binary.
# Keep the top-level map, which already references both public headers.
headers="$derived/SourcePackages/checkouts/swift-ignore/IgnoreRust.xcframework/macos-arm64_x86_64/Headers"
for duplicate in "$headers/libIgnore/module.modulemap" "$derived/Build/Products/Release/include/libIgnore/module.modulemap"; do
    if [[ -f "$duplicate" ]] && /usr/bin/grep -q '^module IgnoreRust {' "$duplicate" &&
       /usr/bin/grep -q 'header "libIgnore/ignore.h"' "$headers/module.modulemap"; then
        /bin/unlink "$duplicate"
    fi
done

/usr/bin/xcodebuild "${project_args[@]}" -skipPackageUpdates -disableAutomaticPackageResolution \
    -configuration Release -destination 'platform=macOS,arch=arm64' \
    ARCHS=arm64 ONLY_ACTIVE_ARCH=YES MACOSX_DEPLOYMENT_TARGET=13.0 CODE_SIGNING_ALLOWED=NO build

app="$PWD/build/zh-arm64/Build/Products/Release/Clop.app"
archs="$(/usr/bin/xcrun lipo -archs "$app/Contents/MacOS/Clop")"
[[ "$archs" == arm64 ]]
printf '构建产物（arm64，待签名） %s\n' "$app"

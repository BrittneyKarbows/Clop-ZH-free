import Cocoa
import Combine
import Defaults
import Foundation
import Lowtech
import os
import SwiftUI

private let log = Logger(subsystem: LOG_SUBSYSTEM, category: "ShortcutsCompat")

func runShortcutProcess(_ shortcut: Shortcut, _ file: String, outFile: String) -> Process? {
    log.debug("Running shortcut \(shortcut.identifier) on \(file) -> \(outFile)")
    return ShortcutsFetcher.run(identifier: shortcut.identifier, inputPath: file, outputPath: outFile)
}

func startShortcutWatcher() {
    let database = URL.libraryDirectory.appendingPathComponent("Shortcuts/Shortcuts.sqlite")
    guard FileManager.default.isReadableFile(atPath: database.path) else { return }
    SHM.startWatching()
}

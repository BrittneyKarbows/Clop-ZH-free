import Cocoa
import Combine
import Defaults
import Foundation
#if !DEBUG
    import Ignore
#endif
import Lowtech
import os
import System
import UniformTypeIdentifiers

private let log = Logger(subsystem: LOG_SUBSYSTEM, category: "FileOptimisationWatcher")

extension EonilFSEventsEvent: @retroactive Hashable {
    public static func == (lhs: EonilFSEventsEvent, rhs: EonilFSEventsEvent) -> Bool {
        lhs.path == rhs.path
    }

    public func hash(into hasher: inout Hasher) {
        hasher.combine(path)
    }
}

@MainActor
class FileOptimisationWatcher {
    init(
        pathsKey: Defaults.Key<[String]>,
        enabledKey: Defaults.Key<Bool>,
        maxFilesToHandleKey: Defaults.Key<Int>,
        fileType: ClopFileType,
        shouldHandle: @escaping @MainActor (EonilFSEventsEvent) async -> Bool,
        cancel: @escaping (FilePath) -> Void,
        handler: @escaping (FilePath) -> Void
    ) {
        self.pathsKey = pathsKey
        self.enabledKey = enabledKey
        self.maxFilesToHandleKey = maxFilesToHandleKey
        self.fileType = fileType
        self.shouldHandle = shouldHandle
        self.cancel = cancel
        self.handler = handler

        pub(pathsKey).sink { [weak self] change in
            self?.paths = change.newValue.map(\.resolvedPath)
            self?.startWatching()
        }.store(in: &observers)

        pub(enabledKey).sink { [weak self] change in
            guard let self else { return }

            enabled = change.newValue
            if change.newValue {
                startWatching()
            } else if watching {
                watching = false
                LowtechFSEvents.stopWatching(for: ObjectIdentifier(self))
            }
        }.store(in: &observers)

        pub(maxFilesToHandleKey).sink { [weak self] change in
            self?.maxFilesToHandle = change.newValue
        }.store(in: &observers)

        pub(.pauseAutomaticOptimisations).sink { [weak self] change in
            guard let self else { return }

            if change.newValue {
                if watching {
                    watching = false
                    LowtechFSEvents.stopWatching(for: ObjectIdentifier(self))
                }
            } else {
                startWatching()
            }
        }.store(in: &observers)

        startWatching()
    }

    deinit {
        guard watching else { return }
        watching = false
        LowtechFSEvents.stopWatching(for: ObjectIdentifier(self))
    }

    var semaphore = DispatchSemaphore(value: 1)

    var watching = false
    var fileType: ClopFileType

    /// Bumped on every `startWatching()` so the off-main existence check of a superseded call can be
    /// discarded when it finally returns, instead of starting a watcher on paths that moved on.
    var watchGeneration = 0
    let existenceCheckQueue = DispatchQueue(label: "com.local.ClopChinese.watcher-existence", qos: .utility)

    var pathsKey: Defaults.Key<[String]>
    var enabledKey: Defaults.Key<Bool>
    /// Absolute, ready for FSEvents. Defaults stores them portable (`~/…`), see `String.portablePath`.
    lazy var paths: [String] = Defaults[pathsKey].map(\.resolvedPath)
    lazy var enabled: Bool = Defaults[enabledKey]

    var maxFilesToHandleKey: Defaults.Key<Int>
    lazy var maxFilesToHandle: Int = Defaults[maxFilesToHandleKey]

    var handler: (FilePath) -> Void
    var cancel: (FilePath) -> Void
    var shouldHandle: @MainActor (EonilFSEventsEvent) async -> Bool

    var observers = Set<AnyCancellable>()
    var justAddedFiles = Set<EonilFSEventsEvent>()
    var cancelledFiles = Set<FilePath>()
    var alreadyOptimisedFiles = Set<String>()
    var addedFileRemovers = [FilePath: DispatchWorkItem]()
    var alreadyOptimisedFileRemovers = [String: DispatchWorkItem]()

    let startedWatchingAt = Date()

    lazy var delayOptimiserID = "file-watcher-delay-\(fileType.rawValue)"
    var delayOptimiser: Optimiser?

    var addedFilesCleaner: DispatchWorkItem? {
        didSet {
            oldValue?.cancel()
        }
    }
    var addedFilesProcessor: DispatchWorkItem? {
        didSet {
            oldValue?.cancel()
        }
    }

    var clopIgnoreFileName: String {
        ".clopignore-\(fileType.rawValue)"
    }

    var withinSafeMeasureTime: Bool {
        startedWatchingAt.timeIntervalSinceNow > -30 && Defaults[.launchCount] == 1
    }

    static func waitForModificationDateToSettle(_ path: String) async {
        guard let attrs = try? fm.attributesOfItem(atPath: path), let date = attrs[.modificationDate] as? Date else {
            log.warning("Failed to get modification date of \(path)")
            return
        }

        log.debug("Waiting for modification date of \(path) to settle")
        log.debug("Initial modification date: \(date)")
        var lastDate = date
        var validCheckCount = 0
        while true {
            do {
                try await Task.sleep(nanoseconds: 300_000_000) // 300ms
            } catch {
                log.error("Failed to sleep: \(error)")
                return
            }

            guard let attrs = try? fm.attributesOfItem(atPath: path), let date = attrs[.modificationDate] as? Date else {
                log.warning("Failed to get modification date of \(path)")
                return
            }

            if date == lastDate, let path = path.filePath {
                if validCheckCount >= 5 {
                    log.debug("Modification date of \(path) settled at \(date) but final validity check failed too many times, returning")
                    return
                }

                var isValid = false
                do {
                    isValid = try await (path.isValid())
                } catch {
                    log.debug("File \(path) is still being modified, not valid yet: \(error)")
                    validCheckCount += 1
                    continue
                }
                if !isValid {
                    log.debug("File \(path) is still being modified, not valid yet")
                    validCheckCount += 1
                    continue
                }
                log.debug("Modification date of \(path) settled at \(date)")
                return
            }

            log.debug("Modification date of \(path) is still changing: \(lastDate) -> \(date)")
            lastDate = date
        }
    }

    /// The flags and the file name, with no filesystem access, so this is safe on the main thread.
    ///
    /// The existence check that used to live here moved to `fileExists(atPath:)`: `FilePath.exists`
    /// is a blocking `stat`, and a watched folder on a network share or a sleeping disk took the main
    /// thread down with it for 30 seconds from inside the FSEvents callback (CLOP-264).
    func isAddedFile(event: EonilFSEventsEvent) -> Bool {
        guard let flag = event.flag, let stem = event.path.filePath?.stem, !stem.starts(with: ".") else {
            return false
        }

        return flag.isDisjoint(with: [.historyDone, .itemRemoved]) &&
            flag.contains(.itemIsFile) &&
            flag.hasElements(from: [.itemCreated, .itemRenamed, .itemModified])
    }

    /// The same existence check, off the main thread. See `isAddedFile`.
    ///
    /// A dataless file counts as missing. When iCloud evicts a file to free space, the eviction
    /// arrives as `.itemModified`, and any read in `shouldHandle` (the image header decode for the
    /// resolution limits) makes iCloud download it again. The download makes it evictable again,
    /// so a file in a watched iCloud folder went through its automation every minute or two while
    /// macOS was reclaiming space. `stat` reads the flags without downloading.
    nonisolated func isLocalFile(atPath path: String) async -> Bool {
        await Task.detached(priority: .utility) {
            var st = stat()
            guard stat(path, &st) == 0 else { return false }
            guard st.st_flags & UInt32(SF_DATALESS) == 0 else {
                log.debug("Skipping \(path): content evicted to iCloud")
                return false
            }
            return true
        }.value
    }

    func stopWatching() {
        if watching {
            semaphore.wait()
            defer { semaphore.signal() }

            watching = false
            LowtechFSEvents.stopWatching(for: ObjectIdentifier(self))
        }
    }

    func startWatching() {
        stopWatching()

        let pathsToCheck = paths
        guard !pathsToCheck.isEmpty, enabled, !Defaults[.pauseAutomaticOptimisations] else { return }

        watchGeneration += 1
        let generation = watchGeneration
        let typeName = fileType.description

        // FSEvents refuses to start the whole stream if any single path is missing, so a folder on an
        // unmounted volume, or one that only exists on another Mac (settings sync through iCloud), would
        // silently stop every other watched folder from working. Skip the missing ones rather than
        // deleting them from the stored list: watching restarts on every settings change, so a folder
        // comes back on its own once its volume is mounted.
        //
        // The check itself runs off the main thread because `fileExists` blocks until the network times
        // out on a stale SMB/NFS mount, and this method is called from the settings observers on the main
        // actor (CLOP-GE hangs in `FilePath.exists.getter`).
        existenceCheckQueue.async { [weak self] in
            let existingPaths = pathsToCheck.filter { fm.fileExists(atPath: $0) }
            for path in pathsToCheck where !existingPaths.contains(path) {
                log.debug("Not watching \(path) for \(typeName) optimisation, folder doesn't exist")
            }
            mainActor { [weak self] in
                // A slower check from a superseded call must not start a watcher with stale paths, and
                // the settings it was based on may have changed while it was blocked.
                guard let self, generation == watchGeneration, enabled, !Defaults[.pauseAutomaticOptimisations] else { return }
                startWatching(existingPaths: existingPaths)
            }
        }
    }

    @MainActor
    func checkEventAndProcess(_ event: EonilFSEventsEvent) async {
        let shouldContinue = await MainActor.run { [weak self] in
            guard let self, enabled else { return false }
            // guard !alreadyOptimisedFiles.contains(event.path) else { return false }
            // guard shouldHandle(event) else { return false }

            if let root = paths.first(where: { event.path.hasPrefix($0) }), let ignorePath = "\(root)/\(clopIgnoreFileName)".existingFilePath, event.path.isIgnored(in: ignorePath.string) {
                log.debug("Ignoring \(event.path) because it's in \(ignorePath.string)")
                return false
            }

            guard !hasSpuriousEvent(event) else { return false }

            guard justAddedFiles.count <= maxFilesToHandle else {
                let notice = "More than \(maxFilesToHandle) \(fileType.rawValue)s appeared in the\n`\(justAddedFiles.first!.path.filePath?.dir.shellString ?? "folder")`, ignoring…"
                log.debug("\(notice)")
                showNotice(notice)
                for path in justAddedFiles.compactMap(\.path.existingFilePath).set.subtracting(cancelledFiles) {
                    log.debug("Cancelling optimisation on \(path)")
                    cancel(path)
                    cancelledFiles.insert(path)
                }
                addedFilesCleaner = mainAsyncAfter(ms: 1000) { [weak self] in
                    log.debug("Cleaning up justAddedFiles and cancelledFiles")
                    self?.cancelledFiles.removeAll()
                    self?.justAddedFiles.removeAll()
                }

                return false
            }

            return true
        }

        guard shouldContinue else { return }
        await Self.waitForModificationDateToSettle(event.path)

        if pauseForNextClipboardEvent {
            log.debug("Skipping \(self.fileType.description) \(event.path) because Clop was paused")
            pauseForNextClipboardEvent = false
            return
        }

        do {
            try await process(event: event)
        } catch {
            log.error("Failed to process \(self.fileType.rawValue) \(event.path) file event: \(error)")
        }
    }

    func hasSpuriousEvent(_ event: EonilFSEventsEvent) -> Bool {
        guard withinSafeMeasureTime, !justAddedFiles.isEmpty else {
            return false
        }

        guard justAddedFiles.count <= 5 else {
            log.warning("More than 5 file events on first launch (\(self.justAddedFiles.count))")

            addedFilesProcessor = nil
            enabled = false
            stopWatching()
            Defaults[enabledKey] = false
            justAddedFiles.removeAll()
            cancelledFiles.removeAll()

            delayOptimiser?.remove(after: 0)
            delayOptimiser = nil

            let alert = NSAlert()
            alert.messageText = "文件事件过多"
            alert.informativeText = """
            Clop detected a large number of file change events that happened as soon as Clop started watching the folders.

            This is most likely caused by a third-party app that is constantly modifying files in the folders you selected to automatically optimise.

            To avoid altering files you don't intend to, Clop will stop automatic optimisation in these folders. You can re-enable this feature in the settings.
            """
            alert.addButton(withTitle: "OK")
            alert.addButton(withTitle: "Open Settings")
            alert.alertStyle = .critical
            focus()

            if alert.runModal() == .alertSecondButtonReturn {
                settingsViewManager.tab = fileType.tab
                WM.open("settings")
                focus()
            }

            return true
        }

        delayOptimiser = OM.optimiser(id: delayOptimiserID, type: .unknown, operation: "Initialising file watcher", hidden: false, source: .fileWatcher, indeterminateProgress: true)
        addedFilesProcessor = mainAsyncAfter(ms: 3000) { [weak self] in
            guard let self else { return }
            for event in justAddedFiles.filter({ ev in
                guard let path = ev.path.existingFilePath else { return false }
                return !self.cancelledFiles.contains(path)
            }) {
                Task { [weak self] in try await self?.process(event: event) }
            }
            justAddedFiles.removeAll()
            delayOptimiser?.remove(after: 0)
            delayOptimiser = nil
        }

        return true
    }

    @MainActor
    func process(event: EonilFSEventsEvent) async throws {
        try await Task.sleep(nanoseconds: 300_000_000)
        guard var path = event.path.existingFilePath, !self.cancelledFiles.contains(path) else { return }

        let oldPath = path
        var resolvedNewPath: FilePath?
        if let newPath = try getTemplatedPath(type: fileType, path: path), newPath != path {
            alreadyOptimisedFiles.insert(newPath.string)
            alreadyOptimisedFiles.insert(path.string)
            path = try path.copy(to: newPath, force: true)
            try? oldPath.setOptimisationStatusXattr("original-processed")
            resolvedNewPath = newPath
        }

        DebugDump.record("[fsevent] >>> optimising \(path.string) (\(fileType.description) watcher)")
        try? await withOptimisationReady {
            self.handler(path)
        }
        alreadyOptimisedFileRemovers[oldPath.string]?.cancel()
        let protectionMs = Defaults[.optimisedFileProtectionMs]
        alreadyOptimisedFileRemovers[oldPath.string] = mainAsyncAfter(ms: protectionMs) { [weak self] in
            self?.alreadyOptimisedFiles.remove(oldPath.string)
            self?.alreadyOptimisedFileRemovers.removeValue(forKey: oldPath.string)
        }
        if let newPathStr = resolvedNewPath?.string {
            alreadyOptimisedFileRemovers[newPathStr]?.cancel()
            alreadyOptimisedFileRemovers[newPathStr] = mainAsyncAfter(ms: protectionMs) { [weak self] in
                self?.alreadyOptimisedFiles.remove(newPathStr)
                self?.alreadyOptimisedFileRemovers.removeValue(forKey: newPathStr)
            }
        }
    }


    private func startWatching(existingPaths: [String]) {
        guard !existingPaths.isEmpty else { return }

        do {
            try LowtechFSEvents.startWatching(paths: existingPaths, for: ObjectIdentifier(self), latency: 0.3, flags: [.noDefer, .fileEvents, .ignoreSelf, .markSelf]) { [weak self] event in
                guard event.flag?.contains(.ownEvent) == false else { return }
                // The FSEvents callback is delivered on the main thread. Return immediately and do the
                // work on the main actor: `shouldHandle` runs its blocking filesystem checks (xattr,
                // size stat, image-header decode) off the main thread internally, so the main thread is
                // never blocked on file I/O during a burst of events or on a slow/network volume (ANR).
                Task { @MainActor [weak self] in
                    // The in-memory checks come first and the `stat` last, so a burst of events for
                    // files Clop already knows about costs no filesystem access at all.
                    guard !SWIFTUI_PREVIEW, !BM.decompressingBinaries, let self, enabled, isAddedFile(event: event),
                          !self.alreadyOptimisedFiles.contains(event.path),
                          !OM.optimisers.contains(where: { $0.url?.path == event.path }),
                          await isLocalFile(atPath: event.path), let path = event.path.filePath,
                          await shouldHandle(event)
                    else { return }

                    // The bookkeeping below has no suspension points, so the main actor already
                    // serialises it; the semaphore is kept to mirror the original guard against
                    // stop/startWatching and always returns immediately here.
                    semaphore.wait()
                    defer { self.semaphore.signal() }

                    let typeName = fileType.description
                    let isNewFile = justAddedFiles.insert(event).inserted

                    if !withinSafeMeasureTime {
                        addedFileRemovers[path]?.cancel()
                        addedFileRemovers[path] = mainAsyncAfter(ms: 1000) { [weak self] in
                            log.debug("Removed \(path.string) from justAddedFiles in the \(typeName) watcher")
                            self?.justAddedFiles.remove(event)
                            self?.addedFileRemovers.removeValue(forKey: path)
                        }
                    }

                    // A single download/save produces several FSEvents for the same path (rename into
                    // place, then quarantine/metadata writes); only the first one should start a
                    // processing task, the settle-wait inside it handles the follow-up writes.
                    guard isNewFile else {
                        log.debug("Skipping duplicate event for \(path.string) in the \(typeName) watcher")
                        return
                    }
                    addedFilesCleaner = nil
                    log.debug("Added \(path.string) to justAddedFiles in the \(typeName) watcher")
                    cancelledFiles.remove(path)
                    DebugDump.record("[fsevent] >>> picked up by Clop \(typeName) watcher: \(path.string)")

                    Task { [weak self] in await self?.checkEventAndProcess(event) }
                }
            }
            watching = true
        } catch {
            log.error("Failed to start watching \(self.fileType.rawValue) folders: \(error)")
            return
        }
    }

}

import Cocoa
import Defaults
import Foundation
import ImageIO
import Lowtech
import System
import UniformTypeIdentifiers

enum PipelineAction: CustomStringConvertible {
    case convert(format: UTType)
    case optimise
    case downscale(factor: Double?, cropSize: CropSize?)
    /// `frames` overrides the playbackSpeedFrameBehaviour setting for this one pass.
    case changePlaybackSpeed(factor: Double, frames: PlaybackSpeedFrameBehaviour? = nil)
    case removeAudio
    case runShortcut(Shortcut)

    var description: String {
        switch self {
        case let .convert(format):
            "convert(\(format.preferredFilenameExtension ?? "?"))"
        case .optimise:
            "optimise"
        case let .downscale(factor, cropSize):
            if cropSize != nil {
                "downscale(crop)"
            } else if let factor {
                "downscale(\((factor * 100).intround)%)"
            } else {
                "downscale"
            }
        case let .changePlaybackSpeed(factor, frames):
            "changePlaybackSpeed(\(factor)x\(frames.map { ", \($0.dslValue) frames" } ?? ""))"
        case .removeAudio:
            "removeAudio"
        case let .runShortcut(shortcut):
            "runShortcut(\(shortcut.name))"
        }
    }

    var isDownscale: Bool {
        if case .downscale = self {
            return true
        }
        return false
    }

    var isOptimise: Bool {
        if case .optimise = self {
            return true
        }
        return false
    }

    var isConvert: Bool {
        if case .convert = self {
            return true
        }
        return false
    }

    var isChangePlaybackSpeed: Bool {
        if case .changePlaybackSpeed = self {
            return true
        }
        return false
    }

    var isRemoveAudio: Bool {
        if case .removeAudio = self {
            return true
        }
        return false
    }
}

// MARK: - Pipeline Step Data Model

enum EncoderQuality: String, Codable, CaseIterable, Defaults.Serializable {
    case aggressive, medium, lossless
}

enum VideoEncoderQuality: String, Codable, CaseIterable, Defaults.Serializable {
    case efficient, highQuality, lossless
}

enum VideoCodec: String, Codable, CaseIterable, Defaults.Serializable {
    case hevcVideoToolbox = "hevc_videotoolbox"
    case libx265
    case libsvtav1
}

enum ClipboardCopyFormat: String, Codable, CaseIterable, Defaults.Serializable {
    case path, imageData, markdown
}

enum StepLocation: String, Codable, CaseIterable, Defaults.Serializable {
    case inPlace, sameFolder, temporaryFolder
}

// MARK: - FilterCondition

struct FilterCondition: Codable, Hashable, Defaults.Serializable {
    var types: [String]?
    var regex: String?
    var nameContains: String?
    var nameIs: String?
    var fileSizeGreaterThan: Int?
    var fileSizeLowerThan: Int?
    var widthGreaterThan: Int?
    var widthLowerThan: Int?
    var heightGreaterThan: Int?
    var heightLowerThan: Int?
    var dpiGreaterThan: Int?
    var dpiLowerThan: Int?
    var minFileSize: Int?
    var minResolution: Int?
    var copiedBy: String?

    var isEmpty: Bool {
        let noText: Bool = types == nil && regex == nil && nameContains == nil && nameIs == nil
        let noSize: Bool = fileSizeGreaterThan == nil && fileSizeLowerThan == nil && minFileSize == nil
        let noDims: Bool = widthGreaterThan == nil && widthLowerThan == nil && heightGreaterThan == nil && heightLowerThan == nil && minResolution == nil
        let noDPI: Bool = dpiGreaterThan == nil && dpiLowerThan == nil
        let noApp: Bool = copiedBy == nil
        return noText && noSize && noDims && noDPI && noApp
    }

    func evaluate(file: FilePath, context: TemplateContext, sourceAppBundleID: String? = nil, sourceAppName: String? = nil) -> (matches: Bool, captures: [String]) {
        let name = file.lastComponent?.string ?? ""
        var captures: [String] = []

        if let types, !types.isEmpty {
            let ext = file.extension ?? ""
            let fileUTType = UTType(filenameExtension: ext)
            let matchesType = types.contains { typeStr in
                // Accept both UTType identifiers ("public.png") and extensions ("png")
                guard let uttype = UTType(typeStr) ?? UTType(filenameExtension: typeStr) else { return false }
                return fileUTType?.conforms(to: uttype) ?? false
            }
            if !matchesType {
                return (false, [])
            }
        }

        if let regex, !regex.isEmpty {
            // Smart case: insensitive when the pattern is all lowercase, sensitive when
            // it contains an uppercase literal. Escape sequences like \S or \W don't count.
            let literals = regex.replacingOccurrences(of: #"\\."#, with: "", options: .regularExpression)
            let options: NSRegularExpression.Options = literals.contains(where: \.isUppercase) ? [] : [.caseInsensitive]
            guard let re = try? NSRegularExpression(pattern: regex, options: options) else { return (false, []) }
            let range = NSRange(name.startIndex..., in: name)
            guard let match = re.firstMatch(in: name, range: range) else { return (false, []) }
            for i in 1 ..< match.numberOfRanges {
                if let r = Range(match.range(at: i), in: name) {
                    captures.append(String(name[r]))
                }
            }
        }

        if let nameContains, !nameContains.isEmpty {
            if !name.localizedCaseInsensitiveContains(nameContains) {
                return (false, [])
            }
        }

        if let nameIs, !nameIs.isEmpty {
            if name != nameIs {
                return (false, [])
            }
        }

        if let fileSizeGreaterThan {
            guard let size = file.fileSize(), size > fileSizeGreaterThan else { return (false, []) }
        }

        if let fileSizeLowerThan {
            guard let size = file.fileSize(), size < fileSizeLowerThan else { return (false, []) }
        }

        if let widthGreaterThan {
            guard let w = imageWidth(file), w > widthGreaterThan else { return (false, []) }
        }

        if let widthLowerThan {
            guard let w = imageWidth(file), w < widthLowerThan else { return (false, []) }
        }

        if let heightGreaterThan {
            guard let h = imageHeight(file), h > heightGreaterThan else { return (false, []) }
        }

        if let heightLowerThan {
            guard let h = imageHeight(file), h < heightLowerThan else { return (false, []) }
        }

        if let dpiGreaterThan {
            guard let dpi = fileDPI(file), dpi > dpiGreaterThan else { return (false, []) }
        }

        if let dpiLowerThan {
            guard let dpi = fileDPI(file), dpi < dpiLowerThan else { return (false, []) }
        }

        if let minFileSize {
            guard let size = file.fileSize(), size >= minFileSize else { return (false, []) }
        }

        if let minResolution {
            guard let w = imageWidth(file), let h = imageHeight(file), w >= minResolution, h >= minResolution else { return (false, []) }
        }

        if let copiedBy, !copiedBy.isEmpty {
            // Fuzzy match the source app: the bundle id or display name must contain the query,
            // case-insensitively (so "safari" matches both "Safari" and "com.apple.Safari").
            let needle = copiedBy.lowercased()
            let haystacks = [sourceAppBundleID, sourceAppName].compactMap { $0?.lowercased() }
            guard haystacks.contains(where: { $0.contains(needle) }) else { return (false, []) }
        }

        return (true, captures)
    }
}

private func imageWidth(_ file: FilePath) -> Int? {
    guard let source = CGImageSourceCreateWithURL(file.url as CFURL, nil),
          let props = CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [CFString: Any],
          let w = props[kCGImagePropertyPixelWidth] as? Int
    else { return nil }
    return w
}

private func imageHeight(_ file: FilePath) -> Int? {
    guard let source = CGImageSourceCreateWithURL(file.url as CFURL, nil),
          let props = CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [CFString: Any],
          let h = props[kCGImagePropertyPixelHeight] as? Int
    else { return nil }
    return h
}

private func imageDPI(_ file: FilePath) -> Int? {
    guard let source = CGImageSourceCreateWithURL(file.url as CFURL, nil),
          let props = CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [CFString: Any]
    else { return nil }
    if let dpi = (props[kCGImagePropertyDPIWidth] as? NSNumber)?.intValue, dpi > 0 {
        return dpi
    }
    if let dpi = (props[kCGImagePropertyDPIHeight] as? NSNumber)?.intValue, dpi > 0 {
        return dpi
    }
    return nil
}

/// Resolve a DPI value for the dpi filter: images expose it via metadata, PDFs via the
/// highest embedded-image DPI scan. Returns nil when no DPI information is available
/// (so the guard fails, matching how width/height behave for non-image files).
private func fileDPI(_ file: FilePath) -> Int? {
    if file.extension?.lowercased() == "pdf" {
        return scanPDFMaxImageDPI(at: file)
    }
    return imageDPI(file)
}

// MARK: - PipelineStep

enum PipelineStep: Encodable, Hashable, Identifiable, Defaults.Serializable {
    // Processing steps (explicit, no implicit optimisation)
    case optimise(encoder: EncoderQuality = .medium, adaptive: Bool = false, videoEncoder: VideoEncoder? = nil, dpi: Int? = nil, location: String = "inPlace", compression: CompressionQuality? = nil)
    case downscale(factor: Double, location: String = "inPlace")
    case lowerBitrate(kbps: Int, location: String = "inPlace")
    case convert(to: String, location: String = "sameFolder")
    case crop(width: Int? = nil, height: Int? = nil, longEdge: Int? = nil, aspectRatio: String? = nil, smartCrop: Bool = false, location: String = "inPlace")
    case extractPagesAsImages(format: String = "jpeg", quality: String = "medium", location: String = "sameFolder")
    case targetSize(bytes: Int, location: String = "inPlace")
    case stripExif
    case watermark(image: String, position: String = "bottomRight", opacity: Double = 1.0, scale: Double = 0.15, location: String = "inPlace")

    // File path operations (template vars supported)
    case copy(to: String)
    case move(to: String)
    case rename(to: String)
    case delete(path: String = "sourceFile")

    // Filters (pipeline stops silently if condition fails)
    case filterIf(FilterCondition)
    case filterIfNot(FilterCondition)

    /// Media-specific
    case removeAudio
    /// `frames` nil follows the playbackSpeedFrameBehaviour setting.
    case changeSpeed(factor: Double, frames: PlaybackSpeedFrameBehaviour? = nil)
    case capFps(fps: Int)
    case normalize(lufs: Double = -16)

    // Generic actions
    case runScript(path: String? = nil, code: String? = nil)
    case runShortcut(Shortcut)
    case copyToClipboard(format: ClipboardCopyFormat = .path, relativeTo: String? = nil)
    case copyLinkForSending(expiration: TimeInterval? = nil)
    /// Branch off the current result as a second floating result card. No location → the card's
    /// file lives in temp (drag it out to keep it); a location persists it like other steps.
    case fork(location: String? = nil)

    // App integration
    case shelveWith(app: String)
    case uploadWith(app: String)
    case openWith(app: String)

    var id: String {
        switch self {
        case let .optimise(encoder, adaptive, videoEncoder, dpi, location, compression): "optimise-\(videoEncoder?.rawValue ?? encoder.rawValue)-\(adaptive)-\(dpi ?? 0)-\(location)-\(compression.map { "\($0.tier.rawValue):\($0.factor)" } ?? "")"
        case let .downscale(factor, location): "downscale-\(factor)-\(location)"
        case let .lowerBitrate(kbps, location): "lowerBitrate-\(kbps)-\(location)"
        case let .convert(to, location): "convert-\(to)-\(location)"
        case let .crop(width, height, longEdge, aspectRatio, smartCrop, location): "crop-\(aspectRatio ?? "")-\(longEdge ?? width ?? 0)-\(height ?? 0)-\(smartCrop)-\(location)"
        case let .extractPagesAsImages(format, quality, location): "extractPagesAsImages-\(format)-\(quality)-\(location)"
        case let .targetSize(bytes, location): "targetSize-\(bytes)-\(location)"
        case .stripExif: "stripExif"
        case let .watermark(image, position, opacity, scale, location): "watermark-\(image)-\(position)-\(opacity)-\(scale)-\(location)"
        case let .capFps(fps): "capFps-\(fps)"
        case let .normalize(lufs): "normalize-\(lufs)"
        case let .copy(to): "copy-\(to)"
        case let .move(to): "move-\(to)"
        case let .rename(to): "rename-\(to)"
        case let .delete(path): "delete-\(path)"
        case .filterIf: "filterIf"
        case .filterIfNot: "filterIfNot"
        case .removeAudio: "removeAudio"
        case let .changeSpeed(factor, frames): "changeSpeed-\(factor)-\(frames?.dslValue ?? "")"
        case let .runScript(path, code): "runScript-\(code ?? path ?? "")"
        case let .runShortcut(shortcut): "runShortcut-\(shortcut.name)"
        case let .copyToClipboard(format, relativeTo): "copyToClipboard-\(format.rawValue)-\(relativeTo ?? "")"
        case let .copyLinkForSending(expiration): "copyLinkForSending-\(expiration ?? -1)"
        case let .fork(location): "fork-\(location ?? "")"
        case let .shelveWith(app): "shelveWith-\(app)"
        case let .uploadWith(app): "uploadWith-\(app)"
        case let .openWith(app): "openWith-\(app)"
        }
    }

    var stepName: String {
        switch self {
        case .optimise: "optimise"
        case .downscale: "downscale"
        case .lowerBitrate: "lowerBitrate"
        case .convert: "convert"
        case .crop: "crop"
        case .extractPagesAsImages: "extractPagesAsImages"
        case .targetSize: "targetSize"
        case .stripExif: "stripExif"
        case .watermark: "watermark"
        case .capFps: "capFps"
        case .normalize: "normalize"
        case .copy: "copy"
        case .move: "move"
        case .rename: "rename"
        case .delete: "delete"
        case .filterIf: "if"
        case .filterIfNot: "ifNot"
        case .removeAudio: "removeAudio"
        case .changeSpeed: "changeSpeed"
        case .runScript: "runScript"
        case .runShortcut: "runShortcut"
        case .copyToClipboard: "copyToClipboard"
        case .copyLinkForSending: "copyLinkForSending"
        case .fork: "fork"
        case .shelveWith: "shelveWith"
        case .uploadWith: "uploadWith"
        case .openWith: "openWith"
        }
    }

    var displayString: String {
        switch self {
        case let .optimise(encoder, adaptive, videoEncoder, dpi, location, compression):
            var params = ["encoder: \(videoEncoder?.rawValue ?? encoder.rawValue)"]
            if adaptive {
                params.append("adaptive: true")
            }
            if let compression {
                params.append("compression: \(compression.factor)")
            }
            if let dpi {
                params.append("dpi: \(dpi)")
            }
            if location != "inPlace" {
                params.append("location: \(location)")
            }
            return "optimise(\(params.joined(separator: ", ")))"
        case let .downscale(factor, location):
            var params = ["factor: \(factor)"]
            if location != "inPlace" {
                params.append("location: \(location)")
            }
            return "downscale(\(params.joined(separator: ", ")))"
        case let .lowerBitrate(kbps, location):
            var params = ["kbps: \(kbps)"]
            if location != "inPlace" {
                params.append("location: \(location)")
            }
            return "lowerBitrate(\(params.joined(separator: ", ")))"
        case let .convert(to, location):
            var params = ["to: \(to)"]
            if location != "sameFolder" {
                params.append("location: \(location)")
            }
            return "convert(\(params.joined(separator: ", ")))"
        case let .crop(width, height, longEdge, aspectRatio, smartCrop, location):
            var params: [String] = []
            if let aspectRatio {
                params.append("aspectRatio: \(aspectRatio)")
            }
            if let longEdge {
                params.append("longEdge: \(longEdge)")
            }
            if let width {
                params.append("width: \(width)")
            }
            if let height {
                params.append("height: \(height)")
            }
            if smartCrop {
                params.append("smartCrop: true")
            }
            if location != "inPlace" {
                params.append("location: \(location)")
            }
            return "crop(\(params.joined(separator: ", ")))"
        case let .extractPagesAsImages(format, quality, location):
            var params: [String] = []
            if format != "jpeg" {
                params.append("format: \(format)")
            }
            if quality != "medium" {
                params.append("quality: \(quality)")
            }
            if location != "sameFolder" {
                params.append("location: \(location)")
            }
            return params.isEmpty ? "extractPagesAsImages" : "extractPagesAsImages(\(params.joined(separator: ", ")))"
        case let .targetSize(bytes, location):
            var params = ["size: \(bytes.humanSize)"]
            if location != "inPlace" {
                params.append("location: \(location)")
            }
            return "targetSize(\(params.joined(separator: ", ")))"
        case .stripExif: return "stripExif"
        case let .watermark(image, position, opacity, scale, location):
            var params = ["image: \"\(image)\""]
            if position != "bottomRight" {
                params.append("position: \(position)")
            }
            if opacity != 1.0 {
                params.append("opacity: \(opacity)")
            }
            if scale != 0.15 {
                params.append("scale: \(scale)")
            }
            if location != "inPlace" {
                params.append("location: \(location)")
            }
            return "watermark(\(params.joined(separator: ", ")))"
        case let .capFps(fps): return "capFps(fps: \(fps))"
        case let .normalize(lufs): return "normalize(lufs: \(lufs))"
        case let .copy(to): return "copy(to: \(to))"
        case let .move(to): return "move(to: \(to))"
        case let .rename(to): return "rename(to: \(to))"
        case let .delete(path): return "delete(path: \(path))"
        case let .filterIf(condition): return "if(\(condition.displayString))"
        case let .filterIfNot(condition): return "ifNot(\(condition.displayString))"
        case .removeAudio: return "removeAudio"
        case let .changeSpeed(factor, frames): return "changeSpeed(factor: \(factor)\(frames.map { ", frames: \($0.dslValue)" } ?? ""))"
        case let .runScript(path, code):
            if let code, !code.isEmpty {
                return "runScript(code: \(code))"
            }
            return "runScript(path: \(path ?? ""))"
        case let .runShortcut(shortcut): return "runShortcut(name: \(shortcut.name))"
        case let .copyToClipboard(format, relativeTo):
            var params = ["format: \(format.rawValue)"]
            if let relativeTo {
                params.append("relativeTo: \(relativeTo)")
            }
            return "copyToClipboard(\(params.joined(separator: ", ")))"
        case let .copyLinkForSending(expiration):
            guard let expiration else { return "copyLinkForSending" }
            let token = expiration <= 0 ? "never" : expirationShortLabel(expiration)
            return "copyLinkForSending(expiration: \(token))"
        case let .fork(location):
            guard let location else { return "fork" }
            return "fork(location: \(location))"
        case let .shelveWith(app): return "shelveWith(app: \(app))"
        case let .uploadWith(app): return "uploadWith(app: \(app))"
        case let .openWith(app): return "openWith(app: \(app))"
        }
    }

    var isProcessingStep: Bool {
        switch self {
        case .optimise, .downscale, .lowerBitrate, .convert, .crop, .extractPagesAsImages, .targetSize, .stripExif, .watermark: true
        default: false
        }
    }

    /// The `location` parameter of processing steps. nil for steps without one.
    var location: String? {
        switch self {
        case let .optimise(_, _, _, _, location, _): location
        case let .downscale(_, location): location
        case let .lowerBitrate(_, location): location
        case let .convert(_, location): location
        case let .crop(_, _, _, _, _, location): location
        case let .extractPagesAsImages(_, _, location): location
        case let .targetSize(_, location): location
        case let .watermark(_, _, _, _, location): location
        default: nil
        }
    }

    /// The crop a `crop` step resolves to, nil for every other step. `aspectRatio` crops to a shape
    /// rather than to pixel dimensions, so it carries `isAspectRatio` and lets `computedSize(from:)`
    /// derive the pixels from each file; it wins over width/height/longEdge when both are given.
    var cropSize: CropSize? {
        guard case let .crop(width, height, longEdge, aspectRatio, smartCrop, _) = self else { return nil }

        if let aspectRatio, let ratio = CropSize(aspectRatio: aspectRatio) {
            return ratio.withSmartCrop(smartCrop)
        }

        let useLongEdge = longEdge != nil
        return CropSize(
            width: useLongEdge ? (longEdge ?? 0) : (width ?? 0),
            height: useLongEdge ? (longEdge ?? 0) : (height ?? 0),
            longEdge: useLongEdge,
            smartCrop: smartCrop
        )
    }

    var isOptimise: Bool {
        if case .optimise = self {
            return true
        }
        return false
    }

    var isFileOperation: Bool {
        switch self {
        case .copy, .move, .rename, .delete: true
        default: false
        }
    }

    var isFilter: Bool {
        switch self {
        case .filterIf, .filterIfNot: true
        default: false
        }
    }

    var category: StepCategory {
        switch self {
        case .optimise, .downscale, .lowerBitrate, .convert, .crop, .extractPagesAsImages, .targetSize, .stripExif, .watermark: .processing
        case .copy, .move, .rename, .delete: .fileOperation
        case .filterIf, .filterIfNot: .filter
        case .removeAudio, .changeSpeed, .capFps, .normalize: .mediaSpecific
        case .runScript, .runShortcut, .copyToClipboard, .copyLinkForSending, .fork, .shelveWith, .uploadWith, .openWith: .action
        }
    }
}

enum StepCategory {
    case processing, fileOperation, filter, mediaSpecific, action

    var nsColor: NSColor {
        switch self {
        case .processing: .systemBlue
        case .fileOperation: .systemGreen
        case .filter: .systemOrange
        case .mediaSpecific: .systemTeal
        case .action: .systemIndigo
        }
    }
}

extension PipelineStep {
    var categoryNSColor: NSColor {
        category.nsColor
    }
}

// MARK: - Backward-compatible Decodable

/// Custom decoder that uses decodeIfPresent with defaults for all defaultable
/// parameters. This ensures old encoded data (missing newly added fields like
/// `location`) decodes correctly instead of failing.
/// Encodable is auto-synthesized on the enum declaration.
extension PipelineStep: Decodable {
    private struct DynKey: CodingKey {
        init(_ s: String) {
            stringValue = s
        }
        init?(stringValue: String) {
            self.stringValue = stringValue
        }
        init?(intValue: Int) {
            nil
        }

        var stringValue: String

        var intValue: Int? {
            nil
        }
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: DynKey.self)

        if container.contains(DynKey("optimise")) {
            let c = try container.nestedContainer(keyedBy: DynKey.self, forKey: DynKey("optimise"))
            self = try .optimise(
                encoder: c.decodeIfPresent(EncoderQuality.self, forKey: DynKey("encoder")) ?? .medium,
                adaptive: c.decodeIfPresent(Bool.self, forKey: DynKey("adaptive")) ?? false,
                videoEncoder: c.decodeIfPresent(VideoEncoder.self, forKey: DynKey("videoEncoder")),
                dpi: c.decodeIfPresent(Int.self, forKey: DynKey("dpi")),
                location: c.decodeIfPresent(String.self, forKey: DynKey("location")) ?? "inPlace",
                // Absent in every pipeline saved before this existed, so decodeIfPresent, not decode.
                compression: c.decodeIfPresent(CompressionQuality.self, forKey: DynKey("compression"))
            )
        } else if container.contains(DynKey("downscale")) {
            let c = try container.nestedContainer(keyedBy: DynKey.self, forKey: DynKey("downscale"))
            self = try .downscale(
                factor: c.decode(Double.self, forKey: DynKey("factor")),
                location: c.decodeIfPresent(String.self, forKey: DynKey("location")) ?? "inPlace"
            )
        } else if container.contains(DynKey("lowerBitrate")) {
            let c = try container.nestedContainer(keyedBy: DynKey.self, forKey: DynKey("lowerBitrate"))
            self = try .lowerBitrate(
                kbps: c.decode(Int.self, forKey: DynKey("kbps")),
                location: c.decodeIfPresent(String.self, forKey: DynKey("location")) ?? "inPlace"
            )
        } else if container.contains(DynKey("convert")) {
            let c = try container.nestedContainer(keyedBy: DynKey.self, forKey: DynKey("convert"))
            self = try .convert(
                to: c.decode(String.self, forKey: DynKey("to")),
                location: c.decodeIfPresent(String.self, forKey: DynKey("location")) ?? "sameFolder"
            )
        } else if container.contains(DynKey("crop")) {
            let c = try container.nestedContainer(keyedBy: DynKey.self, forKey: DynKey("crop"))
            self = try .crop(
                width: c.decodeIfPresent(Int.self, forKey: DynKey("width")),
                height: c.decodeIfPresent(Int.self, forKey: DynKey("height")),
                longEdge: c.decodeIfPresent(Int.self, forKey: DynKey("longEdge")),
                aspectRatio: c.decodeIfPresent(String.self, forKey: DynKey("aspectRatio")),
                smartCrop: c.decodeIfPresent(Bool.self, forKey: DynKey("smartCrop")) ?? false,
                location: c.decodeIfPresent(String.self, forKey: DynKey("location")) ?? "inPlace"
            )
        } else if container.contains(DynKey("extractPagesAsImages")) {
            let c = try container.nestedContainer(keyedBy: DynKey.self, forKey: DynKey("extractPagesAsImages"))
            self = try .extractPagesAsImages(
                format: c.decodeIfPresent(String.self, forKey: DynKey("format")) ?? "jpeg",
                quality: c.decodeIfPresent(String.self, forKey: DynKey("quality")) ?? "medium",
                location: c.decodeIfPresent(String.self, forKey: DynKey("location")) ?? "sameFolder"
            )
        } else if container.contains(DynKey("targetSize")) {
            let c = try container.nestedContainer(keyedBy: DynKey.self, forKey: DynKey("targetSize"))
            self = try .targetSize(
                bytes: c.decode(Int.self, forKey: DynKey("bytes")),
                location: c.decodeIfPresent(String.self, forKey: DynKey("location")) ?? "inPlace"
            )
        } else if container.contains(DynKey("stripExif")) {
            self = .stripExif
        } else if container.contains(DynKey("watermark")) {
            let c = try container.nestedContainer(keyedBy: DynKey.self, forKey: DynKey("watermark"))
            self = try .watermark(
                image: c.decode(String.self, forKey: DynKey("image")),
                position: c.decodeIfPresent(String.self, forKey: DynKey("position")) ?? "bottomRight",
                opacity: c.decodeIfPresent(Double.self, forKey: DynKey("opacity")) ?? 1.0,
                scale: c.decodeIfPresent(Double.self, forKey: DynKey("scale")) ?? 0.15,
                location: c.decodeIfPresent(String.self, forKey: DynKey("location")) ?? "inPlace"
            )
        } else if container.contains(DynKey("capFps")) {
            let c = try container.nestedContainer(keyedBy: DynKey.self, forKey: DynKey("capFps"))
            self = try .capFps(fps: c.decode(Int.self, forKey: DynKey("fps")))
        } else if container.contains(DynKey("normalize")) {
            let c = try container.nestedContainer(keyedBy: DynKey.self, forKey: DynKey("normalize"))
            self = try .normalize(lufs: c.decodeIfPresent(Double.self, forKey: DynKey("lufs")) ?? -16)
        } else if container.contains(DynKey("copy")) {
            let c = try container.nestedContainer(keyedBy: DynKey.self, forKey: DynKey("copy"))
            self = try .copy(to: c.decode(String.self, forKey: DynKey("to")))
        } else if container.contains(DynKey("move")) {
            let c = try container.nestedContainer(keyedBy: DynKey.self, forKey: DynKey("move"))
            self = try .move(to: c.decode(String.self, forKey: DynKey("to")))
        } else if container.contains(DynKey("rename")) {
            let c = try container.nestedContainer(keyedBy: DynKey.self, forKey: DynKey("rename"))
            self = try .rename(to: c.decode(String.self, forKey: DynKey("to")))
        } else if container.contains(DynKey("delete")) {
            let c = try container.nestedContainer(keyedBy: DynKey.self, forKey: DynKey("delete"))
            self = try .delete(path: c.decodeIfPresent(String.self, forKey: DynKey("path")) ?? "sourceFile")
        } else if container.contains(DynKey("filterIf")) {
            let c = try container.nestedContainer(keyedBy: DynKey.self, forKey: DynKey("filterIf"))
            self = try .filterIf(c.decode(FilterCondition.self, forKey: DynKey("_0")))
        } else if container.contains(DynKey("filterIfNot")) {
            let c = try container.nestedContainer(keyedBy: DynKey.self, forKey: DynKey("filterIfNot"))
            self = try .filterIfNot(c.decode(FilterCondition.self, forKey: DynKey("_0")))
        } else if container.contains(DynKey("removeAudio")) {
            self = .removeAudio
        } else if container.contains(DynKey("changeSpeed")) {
            let c = try container.nestedContainer(keyedBy: DynKey.self, forKey: DynKey("changeSpeed"))
            self = try .changeSpeed(
                factor: c.decode(Double.self, forKey: DynKey("factor")),
                frames: c.decodeIfPresent(PlaybackSpeedFrameBehaviour.self, forKey: DynKey("frames"))
            )
        } else if container.contains(DynKey("runScript")) {
            let c = try container.nestedContainer(keyedBy: DynKey.self, forKey: DynKey("runScript"))
            self = try .runScript(
                path: c.decodeIfPresent(String.self, forKey: DynKey("path")),
                code: c.decodeIfPresent(String.self, forKey: DynKey("code"))
            )
        } else if container.contains(DynKey("runShortcut")) {
            let c = try container.nestedContainer(keyedBy: DynKey.self, forKey: DynKey("runShortcut"))
            self = try .runShortcut(c.decode(Shortcut.self, forKey: DynKey("_0")))
        } else if container.contains(DynKey("copyToClipboard")) {
            let c = try container.nestedContainer(keyedBy: DynKey.self, forKey: DynKey("copyToClipboard"))
            self = try .copyToClipboard(
                format: c.decodeIfPresent(ClipboardCopyFormat.self, forKey: DynKey("format")) ?? .path,
                relativeTo: c.decodeIfPresent(String.self, forKey: DynKey("relativeTo"))
            )
        } else if container.contains(DynKey("copyLinkForSending")) {
            let c = try? container.nestedContainer(keyedBy: DynKey.self, forKey: DynKey("copyLinkForSending"))
            self = try .copyLinkForSending(expiration: c?.decodeIfPresent(TimeInterval.self, forKey: DynKey("expiration")) ?? nil)
        } else if container.contains(DynKey("fork")) {
            let c = try? container.nestedContainer(keyedBy: DynKey.self, forKey: DynKey("fork"))
            self = try .fork(location: c?.decodeIfPresent(String.self, forKey: DynKey("location")) ?? nil)
        } else if container.contains(DynKey("shelveWith")) {
            let c = try container.nestedContainer(keyedBy: DynKey.self, forKey: DynKey("shelveWith"))
            self = try .shelveWith(app: c.decode(String.self, forKey: DynKey("app")))
        } else if container.contains(DynKey("uploadWith")) {
            let c = try container.nestedContainer(keyedBy: DynKey.self, forKey: DynKey("uploadWith"))
            self = try .uploadWith(app: c.decode(String.self, forKey: DynKey("app")))
        } else if container.contains(DynKey("openWith")) {
            let c = try container.nestedContainer(keyedBy: DynKey.self, forKey: DynKey("openWith"))
            self = try .openWith(app: c.decode(String.self, forKey: DynKey("app")))
        } else {
            throw DecodingError.dataCorrupted(.init(codingPath: container.codingPath, debugDescription: "Unknown PipelineStep case"))
        }
    }
}

extension FilterCondition {
    var displayString: String {
        var parts: [String] = []
        if let types, !types.isEmpty {
            parts.append("types: \(types.joined(separator: ", "))")
        }
        if let regex {
            parts.append("regex: \(regex)")
        }
        if let nameContains {
            parts.append("nameContains: \(nameContains)")
        }
        if let nameIs {
            parts.append("nameIs: \(nameIs)")
        }
        if let fileSizeGreaterThan {
            parts.append("size > \(fileSizeGreaterThan)")
        }
        if let fileSizeLowerThan {
            parts.append("size < \(fileSizeLowerThan)")
        }
        if let widthGreaterThan {
            parts.append("width > \(widthGreaterThan)")
        }
        if let widthLowerThan {
            parts.append("width < \(widthLowerThan)")
        }
        if let heightGreaterThan {
            parts.append("height > \(heightGreaterThan)")
        }
        if let heightLowerThan {
            parts.append("height < \(heightLowerThan)")
        }
        if let dpiGreaterThan {
            parts.append("dpi > \(dpiGreaterThan)")
        }
        if let dpiLowerThan {
            parts.append("dpi < \(dpiLowerThan)")
        }
        if let minFileSize {
            parts.append("size >= \(minFileSize)")
        }
        if let minResolution {
            parts.append("resolution >= \(minResolution)")
        }
        if let copiedBy {
            parts.append("copiedBy: \(copiedBy)")
        }
        return parts.isEmpty ? "" : parts.joined(separator: ", ")
    }
}

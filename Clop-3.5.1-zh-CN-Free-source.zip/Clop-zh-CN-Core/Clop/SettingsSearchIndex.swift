import Foundation

// MARK: - SettingEntry

/// One row of the Settings window, described in the words the user reads.
///
/// The index exists twice over: it backs the search field in Settings, and it is what an agent reads
/// through MCP. Both need the same wording, so a row is described once here rather than once for
/// people and once for machines.
///
/// `keys` names the `Defaults` keys the row writes, in the order the row shows them. A row that hosts
/// no single key (a folder list, a preset gallery, a permissions block) carries none, and still
/// appears so a search can point at the pane.
struct SettingEntry: Identifiable, Hashable {
    let id: String
    let keys: [String]
    let title: String
    let subtitle: String
    /// Words a person would search for that the title and subtitle do not already contain. The point
    /// is the vocabulary mismatch: someone types "mov" or "replace the original", the row says
    /// "Auto-conversion behaviour".
    let keywords: [String]
    let tab: SettingsView.Tabs
    let section: String

    /// The words of each field, kept apart so a hit in the title can outrank one buried in a subtitle.
    var searchFields: [(weight: Double, words: [String])] {
        [
            (3.0, SettingsSearchIndex.words(title)),
            (2.5, keywords.flatMap { SettingsSearchIndex.words($0) }),
            (1.0, SettingsSearchIndex.words(subtitle)),
            (0.6, SettingsSearchIndex.words(section) + SettingsSearchIndex.words(tab.title)),
        ]
    }

    /// The same fields unsplit, for the subsequence pass. It runs across word boundaries, so it needs
    /// the text rather than the words: "autoconv" is nowhere in `searchFields` and sits right there in
    /// "Auto-conversion behaviour".
    var searchTexts: [(weight: Double, text: String)] {
        [
            (3.0, title.lowercased()),
            (2.5, keywords.joined(separator: " ").lowercased()),
            (1.0, subtitle.lowercased()),
            (0.6, "\(section) \(tab.title)".lowercased()),
        ]
    }
}

// MARK: - SettingsSearchIndex

enum SettingsSearchIndex {
    /// Every user-facing row. Hand-maintained; `Scripts/settings-index-audit.py` fails the commit when
    /// a key named here stops existing, or a key gains a control and never gets an entry.
    private static let rows: [SettingEntry] = [
        SettingEntry(
            id: "general.main.syncSettingsCloud", keys: ["syncSettingsCloud"],
            title: "通过 iCloud 与其他 Mac 同步设置",
            subtitle: "",
            keywords: ["icloud", "sync", "other macs", "settings"], tab: .general, section: ""
        ),
        SettingEntry(
            id: "general.main.defaultLinkExpiration", keys: ["defaultLinkExpiration"],
            title: "默认链接有效期",
            subtitle: "安全分享链接的有效时长",
            keywords: [], tab: .general, section: ""
        ),
        SettingEntry(
            id: "general.workingdirectory.workdirCleanupInterval", keys: ["workdirCleanupInterval"],
            title: "清理工作目录",
            subtitle: "定期删除 Clop 工作目录中早于指定时间的文件",
            keywords: [], tab: .general, section: "工作目录"
        ),
        SettingEntry(
            id: "general.optimisation.stripMetadata", keys: ["stripMetadata"],
            title: "移除 EXIF 元数据",
            subtitle: "移除文件中可能泄露个人信息的元数据，如相机、位置和拍摄时间",
            keywords: ["exif", "metadata", "gps", "location", "privacy", "camera"], tab: .general, section: "优化"
        ),
        SettingEntry(
            id: "general.optimisation.preserveColorMetadata", keys: ["preserveColorMetadata"],
            title: "保留色彩配置文件元数据",
            subtitle: "移除 EXIF 元数据时保留色彩配置文件信息",
            keywords: [], tab: .general, section: "优化"
        ),
        SettingEntry(
            id: "general.optimisation.preserveDates", keys: ["preserveDates"],
            title: "保留文件创建与修改日期",
            subtitle: "让优化后的文件沿用原件的创建与修改日期",
            keywords: ["timestamp", "created", "modified", "date", "mtime"], tab: .general, section: "优化"
        ),
        SettingEntry(
            id: "general.optimisation.optimisedFileProtectionMs", keys: ["optimisedFileProtectionMs"],
            title: "重复优化检测间隔",
            subtitle: "如果 iCloud 云盘中的文件被重复优化，请增大此值",
            keywords: [], tab: .general, section: "优化"
        ),

        SettingEntry(
            id: "clipboard.clipboard.enableClipboardOptimiser", keys: ["enableClipboardOptimiser"],
            title: "启用剪贴板优化",
            subtitle: "监听剪贴板并自动优化复制的数据",
            keywords: ["clipboard", "copy", "paste", "watch", "automatic"], tab: .clipboard, section: "剪贴板"
        ),
        SettingEntry(
            id: "clipboard.clipboard.optimiseTIFF", keys: ["optimiseTIFF"],
            title: "TIFF 数据",
            subtitle: "通常来自图形设计应用，可按需跳过",
            keywords: [], tab: .clipboard, section: "剪贴板"
        ),
        SettingEntry(
            id: "clipboard.clipboard.optimiseHEICAVIFClipboard", keys: ["optimiseHEICAVIFClipboard"],
            title: "HEIC 和 AVIF 数据",
            subtitle: "",
            keywords: ["heic", "heif", "avif", "iphone", "photos", "hdr", "copied photo"], tab: .clipboard, section: "剪贴板"
        ),
        SettingEntry(
            id: "clipboard.clipboard.optimiseImagePathClipboard", keys: ["optimiseImagePathClipboard"],
            title: "图像文件",
            subtitle: "从访达复制图像时，剪贴板中保存的是文件路径",
            keywords: [], tab: .clipboard, section: "剪贴板"
        ),
        SettingEntry(
            id: "clipboard.clipboard.optimiseVideoClipboard", keys: ["optimiseVideoClipboard"],
            title: "视频文件",
            subtitle: "复制视频文件路径时优化该文件",
            keywords: [], tab: .clipboard, section: "剪贴板"
        ),
        SettingEntry(
            id: "clipboard.clipboard.optimiseAudioClipboard", keys: ["optimiseAudioClipboard"],
            title: "音频文件",
            subtitle: "复制音频文件路径时优化该文件",
            keywords: [], tab: .clipboard, section: "剪贴板"
        ),
        SettingEntry(
            id: "clipboard.clipboard.optimisePDFClipboard", keys: ["optimisePDFClipboard"],
            title: "PDF 文件",
            subtitle: "复制 PDF 文件路径时优化该文件",
            keywords: [], tab: .clipboard, section: "剪贴板"
        ),
        SettingEntry(
            id: "clipboard.clipboard.appendClipboardResults", keys: ["appendClipboardResults"],
            title: "保留所有剪贴板结果",
            subtitle: "每次剪贴板优化均显示为独立结果，保留上一次的结果",
            keywords: [], tab: .clipboard, section: "剪贴板"
        ),
        SettingEntry(
            id: "clipboard.clipboard.copyConsecutiveClipboardImages", keys: ["copyConsecutiveClipboardImages"],
            title: "在剪贴板中累积已优化的图像",
            subtitle: "连续优化的图像会加入剪贴板的文件列表，方便一次性粘贴到 Pixelmator、Affinity 或备忘录",
            keywords: [], tab: .clipboard, section: "剪贴板"
        ),
        SettingEntry(
            id: "clipboard.clipboard.clipboardAccumulationTimeout", keys: ["clipboardAccumulationTimeout"],
            title: "累积超时",
            subtitle: "连续复制的图像在同一文件列表中的累积时长",
            keywords: [], tab: .clipboard, section: "剪贴板"
        ),

        SettingEntry(
            id: "files.images.optimisedImageBehaviour", keys: ["optimisedImageBehaviour"],
            title: "优化结果的保存位置",
            subtitle: "设置优化结果的保存位置，以及是否替换原件",
            keywords: ["placement", "where", "save", "saved", "replace", "original", "in place", "copy", "same folder", "specific folder", "overwrite", "output"], tab: .files, section: "图像"
        ),
        SettingEntry(
            id: "files.images.convertedImageBehaviour", keys: ["convertedImageBehaviour"],
            title: "兼容格式的自动转换方式",
            subtitle: "优化前自动将兼容性较差的格式转换为广泛支持的格式",
            keywords: ["webp", "avif", "heic", "bmp", "png", "jpeg", "convert", "conversion", "replace", "original", "in place", "copy", "keep", "beside", "automatic", "compatibility"], tab: .files, section: "图像"
        ),
        SettingEntry(
            id: "files.images.manualConvertedImageBehaviour", keys: ["manualConvertedImageBehaviour"],
            title: "手动转换方式",
            subtitle: "通过结果浮窗中的扩展名或右键菜单中的 **转换为…** 选择格式时生效",
            keywords: ["convert to", "manual", "right click", "extension", "click", "replace", "original", "in place", "copy"], tab: .files, section: "图像"
        ),
        SettingEntry(
            id: "files.videos.optimisedVideoBehaviour", keys: ["optimisedVideoBehaviour"],
            title: "优化结果的保存位置",
            subtitle: "设置优化结果的保存位置，以及是否替换原件",
            keywords: ["placement", "where", "save", "saved", "replace", "original", "in place", "copy", "same folder", "specific folder", "overwrite", "output"], tab: .files, section: "视频"
        ),
        SettingEntry(
            id: "files.videos.convertedVideoBehaviour", keys: ["convertedVideoBehaviour"],
            title: "兼容格式的自动转换方式",
            subtitle: "优化前自动将兼容性较差的格式转换为广泛支持的格式",
            keywords: ["mov", "mkv", "webm", "mp4", "convert", "conversion", "replace", "original", "in place", "copy", "keep", "leftover", "beside", "automatic", "compatibility"], tab: .files, section: "视频"
        ),
        SettingEntry(
            id: "files.videos.manualConvertedVideoBehaviour", keys: ["manualConvertedVideoBehaviour"],
            title: "手动转换方式",
            subtitle: "通过结果浮窗中的扩展名或右键菜单中的 **转换为…** 选择格式时生效",
            keywords: ["convert to", "manual", "right click", "extension", "click", "replace", "original", "in place", "copy"], tab: .files, section: "视频"
        ),
        SettingEntry(
            id: "files.audio.optimisedAudioBehaviour", keys: ["optimisedAudioBehaviour"],
            title: "优化结果的保存位置",
            subtitle: "设置优化结果的保存位置，以及是否替换原件",
            keywords: ["placement", "where", "save", "saved", "replace", "original", "in place", "copy", "same folder", "specific folder", "overwrite", "output"], tab: .files, section: "音频"
        ),
        SettingEntry(
            id: "files.audio.convertedAudioBehaviour", keys: ["convertedAudioBehaviour"],
            title: "兼容格式的自动转换方式",
            subtitle: "优化前自动将兼容性较差的格式转换为广泛支持的格式",
            keywords: ["wav", "aiff", "flac", "aac", "mp3", "convert", "conversion", "replace", "original", "in place", "copy", "keep", "beside", "automatic", "compatibility"], tab: .files, section: "音频"
        ),
        SettingEntry(
            id: "files.audio.manualConvertedAudioBehaviour", keys: ["manualConvertedAudioBehaviour"],
            title: "手动转换方式",
            subtitle: "通过结果浮窗中的扩展名或右键菜单中的 **转换为…** 选择格式时生效",
            keywords: ["convert to", "manual", "right click", "extension", "click", "replace", "original", "in place", "copy"], tab: .files, section: "音频"
        ),
        SettingEntry(
            id: "files.pdf.optimisedPDFBehaviour", keys: ["optimisedPDFBehaviour"],
            title: "优化结果的保存位置",
            subtitle: "设置优化结果的保存位置，以及是否替换原件",
            keywords: ["placement", "where", "save", "saved", "replace", "original", "in place", "copy", "same folder", "specific folder", "overwrite", "output"], tab: .files, section: "PDF"
        ),

        SettingEntry(
            id: "video.optimisationrules.removeAudioFromVideos", keys: ["removeAudioFromVideos"],
            title: "移除优化后视频的音轨",
            subtitle: "",
            keywords: ["mute", "silent", "sound", "audio track", "strip"], tab: .video, section: "优化规则"
        ),
        SettingEntry(
            id: "video.optimisationrules.capVideoFPS", keys: ["capVideoFPS", "targetVideoFPS"],
            title: "限制帧率",
            subtitle: "",
            keywords: ["fps", "frame rate", "frames per second", "30fps", "60fps", "smooth", "slow", "half", "quarter", "1/2 of source", "1/4 of source", "choppy", "screen recording", "stuttering"], tab: .video,
            section: "优化规则"
        ),
        SettingEntry(
            id: "video.optimisationrules.playbackSpeedFrameBehaviour", keys: ["playbackSpeedFrameBehaviour"],
            title: "播放速度调整",
            subtitle: "变速时可选择丢帧或重新分配帧的播放时间",
            keywords: [], tab: .video, section: "优化规则"
        ),
        SettingEntry(
            id: "video.compatibility.convertAudioToAAC", keys: ["convertAudioToAAC"],
            title: "将音频转为 AAC",
            subtitle: "将视频音轨重新编码为 AAC 以提高兼容性",
            keywords: [], tab: .video, section: "兼容性"
        ),

        SettingEntry(
            id: "audio.optimisationrules.audioCoverArt", keys: ["audioCoverArt"],
            title: "封面",
            subtitle: "仅支持封面的格式（AAC、MP3、FLAC）可保留封面",
            keywords: ["artwork", "thumbnail", "picture", "embedded", "id3", "m4a", "strip", "remove", "metadata", "tag", "album"], tab: .audio, section: "优化规则"
        ),

        SettingEntry(
            id: "images.main.customNameTemplateForClipboardImages", keys: ["customNameTemplateForClipboardImages"],
            title: "剪贴板图像的文件名模板",
            subtitle: "用于命名从剪贴板保存的图像",
            keywords: [], tab: .images, section: ""
        ),
        SettingEntry(
            id: "images.main.photoCropOrientation", keys: ["photoCropOrientation"],
            title: "「照片」应用的裁剪方向",
            subtitle: "从「照片」应用复制图像时采用的裁剪方式",
            keywords: [], tab: .images, section: ""
        ),
        SettingEntry(
            id: "images.filenamehandling.copyImageFilePath", keys: ["copyImageFilePath"],
            title: "复制图像路径",
            subtitle: "复制优化后的图像数据时，同时复制图像文件路径",
            keywords: [], tab: .images, section: "文件命名"
        ),
        SettingEntry(
            id: "images.filenamehandling.useCustomNameTemplateForClipboardImages", keys: ["useCustomNameTemplateForClipboardImages"],
            title: "使用模板命名剪贴板图像",
            subtitle: "",
            keywords: [], tab: .images, section: "文件命名"
        ),
        SettingEntry(
            id: "images.photosintegration.enablePhotosIntegration", keys: ["enablePhotosIntegration"],
            title: "优化从「照片」应用复制的图像",
            subtitle: "",
            keywords: [], tab: .images, section: "「照片」应用集成"
        ),
        SettingEntry(
            id: "images.optimisationrules.gifFrameDropBehaviour", keys: ["gifFrameDropBehaviour"],
            title: "GIF 丢帧",
            subtitle: "压缩系数超过 80% 时，动态 GIF 会每隔 4、3 或 2 帧丢弃一帧。你可以让动画加快播放，也可以延长每帧停留时间以保持原时长",
            keywords: ["gif", "animation", "frames", "drop", "choppy", "smooth"], tab: .images, section: "优化规则"
        ),
        SettingEntry(
            id: "images.optimisationrules.convertHDRToSDR", keys: ["convertHDRToSDR"],
            title: "将 HDR 转为 SDR",
            subtitle: "",
            keywords: ["hdr", "sdr", "gain map", "xdr", "highlights", "brightness", "tone mapping", "file size"], tab: .images, section: "优化规则"
        ),

        SettingEntry(
            id: "dropzone.dropzone.enableDragAndDrop", keys: ["enableDragAndDrop"],
            title: "启用拖放区",
            subtitle: "可将文件、路径和网址拖到全局拖放区进行优化",
            keywords: ["drop zone", "drag", "drop"], tab: .dropzone, section: "拖放区"
        ),
        SettingEntry(
            id: "dropzone.dropzone.onlyShowDropZoneOnOption", keys: ["onlyShowDropZoneOnOption"],
            title: "按 ⌥ Option 显示拖放区",
            subtitle: "默认隐藏拖放区，拖动文件时按一下 ⌥ Option 即可显示",
            keywords: [], tab: .dropzone, section: "拖放区"
        ),
        SettingEntry(
            id: "dropzone.dropzone.autoCopyToClipboard", keys: ["autoCopyToClipboard"],
            title: "自动将优化后的文件复制到剪贴板",
            subtitle: "将拖放区或监控文件夹中优化后的文件复制到剪贴板，处理完成即可粘贴",
            keywords: [], tab: .dropzone, section: "拖放区"
        ),
        SettingEntry(
            id: "dropzone.batchmode.useBatchModeForFolders", keys: ["useBatchModeForFolders"],
            title: "拖入大量文件时使用批量模式",
            subtitle: "一次拖入多个文件或含多个文件的文件夹时，Clop 会在一个窗口中批量处理。原件会先备份，之后可恢复",
            keywords: [], tab: .dropzone, section: "批量模式"
        ),
        SettingEntry(
            id: "dropzone.batchmode.batchModeFileCountThreshold", keys: ["batchModeFileCountThreshold"],
            title: "启用批量模式的文件数量",
            subtitle: "拖入文件数量超过此值时启用批量模式",
            keywords: [], tab: .dropzone, section: "批量模式"
        ),

        SettingEntry(
            id: "presetZones.showingpresetzones.onlyShowPresetZonesOnControlTapped", keys: ["onlyShowPresetZonesOnControlTapped"],
            title: "按住或轻按 Control 键显示预设区",
            subtitle: "按住时仅在按键期间显示，轻按后保持显示",
            keywords: [], tab: .presetZones, section: "显示预设区"
        ),

        SettingEntry(
            id: "floating.main.enableFloatingResults", keys: ["enableFloatingResults"],
            title: "显示结果浮窗",
            subtitle: "关闭后 Clop 仍会在后台优化文件。拖放区可在「拖放区」设置中单独关闭",
            keywords: [], tab: .floating, section: ""
        ),
        SettingEntry(
            id: "floating.layout.floatingResultsCorner", keys: ["floatingResultsCorner"],
            title: "屏幕位置",
            subtitle: "结果浮窗在屏幕上的显示位置",
            keywords: [], tab: .floating, section: "布局"
        ),
        SettingEntry(
            id: "floating.layout.followCursorScreen", keys: ["followCursorScreen"],
            title: "跟随光标切换显示器",
            subtitle: "光标在另一台显示器上停留几秒后，将结果移到该屏幕",
            keywords: [], tab: .floating, section: "布局"
        ),
        SettingEntry(
            id: "floating.layout.hideFloatingResultTooltips", keys: ["hideFloatingResultTooltips"],
            title: "隐藏按钮提示",
            subtitle: "悬停在结果按钮上时隐藏操作名称",
            keywords: [], tab: .floating, section: "布局"
        ),
        SettingEntry(
            id: "floating.layout.alwaysShowCompactResults", keys: ["alwaysShowCompactResults"],
            title: "始终使用紧凑布局",
            subtitle: "默认在屏幕上有超过 5 个结果时自动切换为紧凑布局",
            keywords: [], tab: .floating, section: "布局"
        ),
        SettingEntry(
            id: "floating.fulllayout.formatPickerStyle", keys: ["formatPickerStyle"],
            title: "格式转换方式",
            subtitle: "结果浮窗中格式转换控件的显示方式",
            keywords: [], tab: .floating, section: "完整布局"
        ),
        SettingEntry(
            id: "floating.fulllayout.showCopyClearButtons", keys: ["showCopyClearButtons"],
            title: "显示「全部复制」和「全部清除」按钮",
            subtitle: "",
            keywords: [], tab: .floating, section: "完整布局"
        ),
        SettingEntry(
            id: "floating.fulllayout.dismissFloatingResultOnDrop", keys: ["dismissFloatingResultOnDrop"],
            title: "拖到外部后关闭结果",
            subtitle: "",
            keywords: [], tab: .floating, section: "完整布局"
        ),
        SettingEntry(
            id: "floating.fulllayout.dismissFloatingResultOnUpload", keys: ["dismissFloatingResultOnUpload"],
            title: "上传到 Dropshare 后关闭结果",
            subtitle: "",
            keywords: [], tab: .floating, section: "完整布局"
        ),
        SettingEntry(
            id: "floating.fulllayout.autoHideFloatingResults", keys: ["autoHideFloatingResults"],
            title: "自动隐藏结果浮窗",
            subtitle: "",
            keywords: [], tab: .floating, section: "完整布局"
        ),
        SettingEntry(
            id: "floating.fulllayout.autoHideFloatingResultsAfter", keys: ["autoHideFloatingResultsAfter"],
            title: "自动隐藏文件结果的延时",
            subtitle: "文件结果消失前的秒数",
            keywords: [], tab: .floating, section: "完整布局"
        ),
        SettingEntry(
            id: "floating.fulllayout.autoHideClipboardResultAfter", keys: ["autoHideClipboardResultAfter"],
            title: "自动隐藏剪贴板结果的延时",
            subtitle: "剪贴板结果消失前的秒数",
            keywords: [], tab: .floating, section: "完整布局"
        ),
        SettingEntry(
            id: "floating.compactlayout.showCompactImages", keys: ["showCompactImages"],
            title: "在紧凑结果中显示图像",
            subtitle: "",
            keywords: [], tab: .floating, section: "紧凑布局"
        ),
        SettingEntry(
            id: "floating.compactlayout.dismissCompactResultOnDrop", keys: ["dismissCompactResultOnDrop"],
            title: "拖到外部后关闭紧凑结果",
            subtitle: "",
            keywords: [], tab: .floating, section: "紧凑布局"
        ),
        SettingEntry(
            id: "floating.compactlayout.dismissCompactResultOnUpload", keys: ["dismissCompactResultOnUpload"],
            title: "上传到 Dropshare 后关闭紧凑结果",
            subtitle: "",
            keywords: [], tab: .floating, section: "紧凑布局"
        ),
        SettingEntry(
            id: "floating.compactlayout.autoClearAllCompactResultsAfter", keys: ["autoClearAllCompactResultsAfter"],
            title: "自动清除全部紧凑结果的延时",
            subtitle: "清除全部紧凑结果前的秒数",
            keywords: [], tab: .floating, section: "紧凑布局"
        ),

        SettingEntry(
            id: "mcp.main.mcpEnabled", keys: ["mcpEnabled"],
            title: "允许代理进行更改",
            subtitle: "允许优化文件、更改设置和保存流程。读取设置和流程始终可用",
            keywords: ["mcp", "agent", "ai", "claude", "cursor", "llm", "automation"], tab: .mcp, section: ""
        ),
        SettingEntry(
            id: "mcp.main.mcpAllowScriptSteps", keys: ["mcpAllowScriptSteps"],
            title: "允许代理编写脚本步骤",
            subtitle: "脚本步骤可以运行任意代码。关闭后，Clop 会拒绝代理创建的含脚本流程，并指出具体步骤。你自己编写的脚本仍可使用",
            keywords: ["mcp", "agent", "script", "shell", "code", "pipeline", "dangerous"], tab: .mcp, section: ""
        ),

        // MARK: added from the domain sweep

        SettingEntry(
            id: "video.watchpaths.videoDirs", keys: [],
            title: "监控路径",
            subtitle: "自动优化这些文件夹中新出现的视频",
            keywords: ["directory", "desktop", "downloads", "monitor", "automatic", "add", "clopignore", "ignore rules", "not picking up", "nothing happens", "unwatched"], tab: .video, section: "监控路径"
        ),
        SettingEntry(
            id: "video.watchpaths.enableAutomaticVideoOptimisations", keys: ["enableAutomaticVideoOptimisations"],
            title: "自动优化视频",
            subtitle: "",
            keywords: ["watch", "folders", "background", "monitor", "stopped working", "disabled", "paused", "desktop", "nothing happens", "turn off"], tab: .video, section: "监控路径"
        ),
        SettingEntry(
            id: "video.optimisationrules.videoCompression", keys: ["videoCompression"],
            title: "压缩",
            subtitle: "",
            keywords: ["encoder", "hardware", "software", "adaptive", "visually lossless", "quality", "crf", "bitrate", "factor", "auto", "slower", "cpu", "battery", "smaller size", "better quality"], tab: .video,
            section: "优化规则"
        ),
        SettingEntry(
            id: "video.optimisationrules.minVideoFPS", keys: ["minVideoFPS"],
            title: "但不少于",
            subtitle: "",
            keywords: ["fps", "minimum", "floor", "10fps", "24fps", "30fps", "60fps", "1/2 of source", "1/4 of source", "fraction", "frame rate", "too slow", "choppy", "stuttering"], tab: .video, section: "优化规则"
        ),
        SettingEntry(
            id: "video.watchedfilefilters.minVideoSizeKB", keys: ["minVideoSizeKB", "maxVideoSizeMB"],
            title: "文件大小",
            subtitle: "仅优化文件大小在指定范围内的文件",
            keywords: ["mb", "kb", "gb", "skipped", "ignored", "too big", "too large", "too small", "threshold", "limit", "range", "untouched"], tab: .video, section: "监控文件的筛选条件"
        ),
        SettingEntry(
            id: "video.watchedfilefilters.minVideoResolution", keys: ["minVideoResolution", "maxVideoResolution"],
            title: "分辨率",
            subtitle: "仅优化宽度和高度在指定范围内的文件",
            keywords: ["px", "pixels", "4k", "1080p", "tiny", "thumbnail", "upscaled", "skipped", "ignored", "threshold", "limit", "range", "dimensions"], tab: .video, section: "监控文件的筛选条件"
        ),
        SettingEntry(
            id: "video.watchedfilefilters.maxVideoFileCount", keys: ["maxVideoFileCount"],
            title: "文件数量",
            subtitle: "一次复制或移动的视频数量超过此值时跳过优化",
            keywords: ["batch", "bulk", "drag", "import", "multiple", "dozens", "threshold", "limit", "nothing happens", "ignored"], tab: .video, section: "监控文件的筛选条件"
        ),
        SettingEntry(
            id: "video.watchedfilefilters.videoFormatsToSkip", keys: ["videoFormatsToSkip"],
            title: "忽略指定扩展名的视频",
            subtitle: "",
            keywords: ["mkv", "m4v", "avi", "webm", "mov", "mp4", "mpeg", "skip", "exclude", "deny list", "format", "untouched", "left alone"], tab: .video, section: "监控文件的筛选条件"
        ),
        SettingEntry(
            id: "video.compatibility.formatsToConvertToMP4", keys: ["formatsToConvertToMP4"],
            title: "转换为 MP4",
            subtitle: "",
            keywords: ["mov", "webm", "mkv", "avi", "mpeg", "m4v", "quicktime", "container", "remux", "incompatible", "cannot open", "unsupported", "automatic"], tab: .video, section: "兼容性"
        ),
        SettingEntry(
            id: "general.editwithexternalapp.editorAppVideo", keys: ["editorAppVideo"],
            title: "视频",
            subtitle: "",
            keywords: ["editor", "external app", "open with", "capcut", "final cut", "premiere", "davinci", "cmd e", "right click", "choose app", "bundle path"], tab: .general, section: "使用外部应用编辑"
        ),
        SettingEntry(
            id: "files.videos.sameFolderNameTemplateVideo", keys: ["sameFolderNameTemplateVideo"],
            title: "原文件夹中优化后视频的文件名模板",
            subtitle: "",
            keywords: ["pattern", "rename", "filename", "suffix", "counter", "date", "clop", "placeholder", "token", "variables"], tab: .files, section: "视频"
        ),
        SettingEntry(
            id: "files.videos.specificFolderNameTemplateVideo", keys: ["specificFolderNameTemplateVideo"],
            title: "指定文件夹中优化后视频的路径模板",
            subtitle: "",
            keywords: ["destination", "output directory", "subfolder", "pattern", "rename", "filename", "where", "placeholder", "token", "location"], tab: .files, section: "视频"
        ),
        SettingEntry(
            id: "files.videos.convertedSameFolderNameTemplateVideo", keys: ["convertedSameFolderNameTemplateVideo"],
            title: "原文件夹中转换后视频的文件名模板",
            subtitle: "",
            keywords: ["mp4", "mov", "pattern", "rename", "filename", "suffix", "leftover", "duplicate", "placeholder", "token"], tab: .files, section: "视频"
        ),
        SettingEntry(
            id: "files.videos.convertedSpecificFolderNameTemplateVideo", keys: ["convertedSpecificFolderNameTemplateVideo"],
            title: "指定文件夹中转换后视频的路径模板",
            subtitle: "",
            keywords: ["mp4", "mov", "destination", "output directory", "subfolder", "pattern", "where", "placeholder", "token", "location"], tab: .files, section: "视频"
        ),
        SettingEntry(
            id: "images.watchpaths.imageDirs", keys: [],
            title: "监控路径",
            subtitle: "自动优化这些文件夹中新出现的图像",
            keywords: ["directories", "desktop", "downloads", "screenshots", "monitor", "automatic", "clopignore", "ignore rules", "per-folder", "add", "remove"], tab: .images, section: "监控路径"
        ),
        SettingEntry(
            id: "images.watchpaths.enableAutomaticImageOptimisations", keys: ["enableAutomaticImageOptimisations"],
            title: "自动优化图像",
            subtitle: "",
            keywords: ["watch", "folder", "background", "screenshots", "stopped working", "nothing happens", "turn off", "pause", "monitor", "checkbox"], tab: .images, section: "监控路径"
        ),
        SettingEntry(
            id: "images.photosintegration.maxCopiedPhotosCount", keys: ["maxCopiedPhotosCount"],
            title: "文件数量",
            subtitle: "",
            keywords: ["photos", "photos.app", "copied at once", "batch", "bulk", "how many", "limit", "threshold", "skip", "albums"], tab: .images, section: "「照片」应用集成"
        ),
        SettingEntry(
            id: "images.photosintegration.maxPhotosLength", keys: ["maxPhotosLength"],
            title: "缩小至",
            subtitle: "",
            keywords: ["photos", "px", "pixels", "resize", "longest edge", "shrink", "huge", "crop", "empty", "unlimited"], tab: .images, section: "「照片」应用集成"
        ),
        SettingEntry(
            id: "images.optimisationrules.imageCompression", keys: ["imageCompression"],
            title: "压缩",
            subtitle: "",
            keywords: ["quality", "factor", "percent", "slider", "adaptive", "lossy", "aggressive", "smaller", "blurry", "artifacts", "entropy", "jpeg", "png", "file size"], tab: .images, section: "优化规则"
        ),
        SettingEntry(
            id: "images.watchedfilefilters.minImageSizeKB", keys: ["minImageSizeKB", "maxImageSizeMB"],
            title: "文件大小",
            subtitle: "",
            keywords: ["skip", "limit", "range", "kb", "mb", "bytes", "megabytes", "too small", "too large", "threshold", "ignore", "not optimised"], tab: .images, section: "监控文件的筛选条件"
        ),
        SettingEntry(
            id: "images.watchedfilefilters.minImageResolution", keys: ["minImageResolution", "maxImageResolution"],
            title: "分辨率",
            subtitle: "",
            keywords: ["pixels", "px", "width", "height", "dimensions", "skip", "limit", "range", "icons", "thumbnails", "huge", "ignore"], tab: .images, section: "监控文件的筛选条件"
        ),
        SettingEntry(
            id: "images.watchedfilefilters.maxImageFileCount", keys: ["maxImageFileCount"],
            title: "文件数量",
            subtitle: "",
            keywords: ["batch", "bulk", "how many", "at once", "copied at once", "moved at once", "limit", "threshold", "skip", "mass copy"], tab: .images, section: "监控文件的筛选条件"
        ),
        SettingEntry(
            id: "images.watchedfilefilters.imageFormatsToSkip", keys: ["imageFormatsToSkip"],
            title: "忽略指定扩展名的图像",
            subtitle: "",
            keywords: ["tiff", "psd", "raw", "skip", "exclude", "never optimise", "leave alone", "format", "blacklist", "deny list"], tab: .images, section: "监控文件的筛选条件"
        ),
        SettingEntry(
            id: "images.compatibility.formatsToConvertToJPEG", keys: ["formatsToConvertToJPEG"],
            title: "转换为 JPEG",
            subtitle: "",
            keywords: ["webp", "avif", "heic", "bmp", "jxl", "tiff", "compatibility", "cannot open", "unsupported", "automatic", "before optimisation"], tab: .images, section: "兼容性"
        ),
        SettingEntry(
            id: "images.compatibility.formatsToConvertToPNG", keys: ["formatsToConvertToPNG"],
            title: "转换为 PNG",
            subtitle: "",
            keywords: ["tiff", "bmp", "webp", "avif", "heic", "jxl", "transparency", "alpha", "lossless", "compatibility", "unsupported", "cannot open"], tab: .images, section: "兼容性"
        ),
        SettingEntry(
            id: "files.images.sameFolderNameTemplateImage", keys: ["sameFolderNameTemplateImage"],
            title: "原文件夹中的文件名模板",
            subtitle: "",
            keywords: ["%f", "suffix", "optimised", "rename", "naming", "filename", "variables", "date", "counter", "overwrite"], tab: .files, section: "图像"
        ),
        SettingEntry(
            id: "files.images.specificFolderNameTemplateImage", keys: ["specificFolderNameTemplateImage"],
            title: "指定文件夹的路径模板",
            subtitle: "",
            keywords: ["%P", "%f", "folder", "destination", "output path", "where", "naming", "pattern", "subfolder", "variables"], tab: .files, section: "图像"
        ),
        SettingEntry(
            id: "files.images.convertedSameFolderNameTemplateImage", keys: ["convertedSameFolderNameTemplateImage"],
            title: "转换后保存在原文件夹时的文件名模板",
            subtitle: "",
            keywords: ["%f", "webp", "heic", "jpeg", "conversion", "rename", "naming", "pattern", "leftover", "variables", "manual convert"], tab: .files, section: "图像"
        ),
        SettingEntry(
            id: "files.images.convertedSpecificFolderNameTemplateImage", keys: ["convertedSpecificFolderNameTemplateImage"],
            title: "转换后保存在指定文件夹时的路径模板",
            subtitle: "",
            keywords: ["%P", "%f", "webp", "heic", "jpeg", "conversion", "destination", "output path", "subfolder", "naming", "manual convert"], tab: .files, section: "图像"
        ),
        SettingEntry(
            id: "general.editwithexternalapp.editorAppImage", keys: ["editorAppImage"],
            title: "图像",
            subtitle: "",
            keywords: ["editor", "external app", "open with", "photoshop", "pixelmator", "affinity", "preview", "edit with", "⌘e", "cmd e", "choose app"], tab: .general, section: "使用外部应用编辑"
        ),
        SettingEntry(
            id: "audio.watchpaths.audioDirs", keys: [],
            title: "监控路径",
            subtitle: "自动优化这些文件夹中新出现的音频",
            keywords: ["folder", "directory", "watched", "monitor", "add folder", "incoming", "music", "downloads", "automatic", "clopignore", "ignore rules", "path list"], tab: .audio, section: "监控路径"
        ),
        SettingEntry(
            id: "audio.watchpaths.enableAutomaticAudioOptimisations", keys: ["enableAutomaticAudioOptimisations"],
            title: "自动优化音频",
            subtitle: "",
            keywords: ["watch", "watcher", "folder", "automatic", "background", "turn on", "turn off", "disable", "stop", "not optimising", "nothing happens"], tab: .audio, section: "监控路径"
        ),
        SettingEntry(
            id: "audio.optimisationrules.audioCompression", keys: ["audioCompression"],
            title: "压缩",
            subtitle: "WAV、AIFF 和 FLAC 为无损格式，压缩系数对它们无效。",
            keywords: ["quality", "bitrate", "kbps", "percent", "slider", "smaller", "file size", "vbr", "variable bitrate", "aac", "mp3", "lossy", "aggressive"], tab: .audio, section: "优化规则"
        ),
        SettingEntry(
            id: "audio.watchedfilefilters.minAudioSizeKB", keys: ["minAudioSizeKB", "maxAudioSizeMB"],
            title: "文件大小",
            subtitle: "",
            keywords: ["skip", "skipped", "ignore", "threshold", "too big", "too small", "limit", "range", "mb", "kb", "large", "small", "podcast", "untouched"], tab: .audio, section: "监控文件的筛选条件"
        ),
        SettingEntry(
            id: "audio.watchedfilefilters.maxAudioFileCount", keys: ["maxAudioFileCount"],
            title: "文件数量",
            subtitle: "",
            keywords: ["batch", "bulk", "many", "at once", "limit", "skip", "copied", "moved", "album", "import", "nothing happens", "too many"], tab: .audio, section: "监控文件的筛选条件"
        ),
        SettingEntry(
            id: "audio.compatibility.formatsToConvertToAAC", keys: ["formatsToConvertToAAC"],
            title: "转换为 AAC（M4A）",
            subtitle: "",
            keywords: ["m4a", "flac", "aiff", "wav", "lossless", "target", "output", "pills", "toggle", "re-encode", "exclusive"], tab: .audio, section: "兼容性"
        ),
        SettingEntry(
            id: "audio.compatibility.formatsToConvertToMP3", keys: ["formatsToConvertToMP3"],
            title: "转换为 MP3",
            subtitle: "",
            keywords: ["wav", "flac", "aiff", "lossless", "target", "output", "pills", "toggle", "re-encode", "exclusive"], tab: .audio, section: "兼容性"
        ),
        SettingEntry(
            id: "general.editwithexternalapp.editorAppAudio", keys: ["editorAppAudio"],
            title: "音频",
            subtitle: "",
            keywords: ["editor", "external app", "open with", "choose", "edit", "cmd e", "audacity", "ferrite", "fission", "default", "waveform"], tab: .general, section: "使用外部应用编辑"
        ),
        SettingEntry(
            id: "files.audio.sameFolderNameTemplateAudio", keys: ["sameFolderNameTemplateAudio"],
            title: "优化后音频的文件名模板",
            subtitle: "",
            keywords: ["filename", "rename", "pattern", "%f", "variables", "placeholder", "same folder", "placement", "copy", "beside", "next to"], tab: .files, section: "音频"
        ),
        SettingEntry(
            id: "files.audio.specificFolderNameTemplateAudio", keys: ["specificFolderNameTemplateAudio"],
            title: "优化后音频的路径模板",
            subtitle: "",
            keywords: ["filename", "rename", "pattern", "%p", "%f", "variables", "placeholder", "specific folder", "placement", "destination", "output"], tab: .files, section: "音频"
        ),
        SettingEntry(
            id: "files.audio.convertedSameFolderNameTemplateAudio", keys: ["convertedSameFolderNameTemplateAudio"],
            title: "转换后音频的文件名模板",
            subtitle: "",
            keywords: ["filename", "rename", "pattern", "%f", "conversion", "wav", "mp3", "aac", "variables", "placeholder", "same folder", "beside"], tab: .files, section: "音频"
        ),
        SettingEntry(
            id: "files.audio.convertedSpecificFolderNameTemplateAudio", keys: ["convertedSpecificFolderNameTemplateAudio"],
            title: "转换后音频的路径模板",
            subtitle: "",
            keywords: ["filename", "rename", "pattern", "%p", "%f", "conversion", "wav", "mp3", "variables", "placeholder", "specific folder", "destination", "output"], tab: .files, section: "音频"
        ),
        SettingEntry(
            id: "pdf.watchpaths.pdfDirs", keys: [],
            title: "监控路径",
            subtitle: "自动优化这些文件夹中新出现的 PDF",
            keywords: ["directories", "monitor", "downloads", "desktop", "clopignore", "ignore rules", "drop", "incoming"], tab: .pdf, section: "监控路径"
        ),
        SettingEntry(
            id: "pdf.watchpaths.enableAutomaticPDFOptimisations", keys: ["enableAutomaticPDFOptimisations"],
            title: "自动优化 PDF",
            subtitle: "",
            keywords: ["watch", "folder", "background", "monitor", "turn off", "disable", "stop", "incoming", "downloads", "not optimising"], tab: .pdf, section: "监控路径"
        ),
        SettingEntry(
            id: "pdf.optimisationrules.pdfDPI", keys: ["pdfDPI"],
            title: "压缩",
            subtitle: "Clop 根据各 PDF 的原始图像密度选择 DPI，并缩小超过该值的图像",
            keywords: ["resolution", "quality", "adaptive", "scanned", "lossless", "150", "300", "blurry", "ghostscript", "shrink", "smaller", "file size", "text quality", "pixelated"], tab: .pdf, section: "优化规则"
        ),
        SettingEntry(
            id: "pdf.watchedfilefilters.minPDFSizeKB", keys: ["minPDFSizeKB", "maxPDFSizeMB"],
            title: "文件大小",
            subtitle: "",
            keywords: ["skip", "too big", "too small", "ignored", "limit", "minimum", "maximum", "mb", "kb", "range", "large", "huge", "not optimised"], tab: .pdf, section: "监控文件的筛选条件"
        ),
        SettingEntry(
            id: "pdf.watchedfilefilters.maxPDFFileCount", keys: ["maxPDFFileCount"],
            title: "文件数量",
            subtitle: "一次复制或移动的 PDF 数量超过此值时跳过优化",
            keywords: ["batch", "bulk", "threshold", "ignored", "watched folder", "nothing happened", "limit", "multiple files"], tab: .pdf, section: "监控文件的筛选条件"
        ),
        SettingEntry(
            id: "general.editwithexternalapp.editorAppPDF", keys: ["editorAppPDF"],
            title: "PDF 文件",
            subtitle: "",
            keywords: ["editor", "open with", "external app", "edit", "choose app", "preview", "acrobat", "pdf expert", "cmd e", "⌘e", "default app", "hand off"], tab: .general, section: "使用外部应用编辑"
        ),
        SettingEntry(
            id: "files.pdf.sameFolderNameTemplatePDF", keys: ["sameFolderNameTemplatePDF"],
            title: "原文件夹中的文件名模板",
            subtitle: "",
            keywords: ["filename", "rename", "pattern", "suffix", "optimised", "tokens", "next to", "beside", "overwrite", "copy"], tab: .files, section: "PDF"
        ),
        SettingEntry(
            id: "files.pdf.specificFolderNameTemplatePDF", keys: ["specificFolderNameTemplatePDF"],
            title: "指定文件夹中的文件名模板",
            subtitle: "",
            keywords: ["path", "filename", "rename", "pattern", "destination", "output", "tokens", "where do they go", "subfolder"], tab: .files, section: "PDF"
        ),
        SettingEntry(
            id: "images.photosintegration.photoCropOrientation", keys: ["photoCropOrientation"],
            title: "「照片」应用的裁剪方向",
            subtitle: "",
            keywords: ["portrait", "landscape", "adaptive", "longest edge", "height", "width", "resize", "aspect", "segmented", "picker"], tab: .images, section: "「照片」应用集成"
        ),
        SettingEntry(
            id: "clipboard.ignoredapps.clipboardIgnoredAppBundleIds", keys: [],
            title: "忽略的应用",
            subtitle: "当前台应用在此列表中时，跳过剪贴板优化",
            keywords: ["denylist", "blacklist", "exclude", "exclusion", "bundle id", "frontmost", "foreground app", "pixelmator", "figma", "password manager", "copy", "paste", "per app"], tab: .clipboard, section: "忽略的应用"
        ),
        SettingEntry(
            id: "general.main.showMenubarIcon", keys: ["showMenubarIcon", "useClassicMenubarIcon", "useGeometricMenubarIcon"],
            title: "菜单栏图标",
            subtitle: "",
            keywords: ["status bar", "tray", "hide", "hidden", "style", "classic", "geometric", "new", "eye slash", "top bar", "missing", "disappeared"], tab: .general, section: ""
        ),
        SettingEntry(
            id: "general.main.allowClopToAppearInScreenshots", keys: ["allowClopToAppearInScreenshots"],
            title: "在截图中显示 Clop 界面",
            subtitle: "",
            keywords: ["screen recording", "capture", "floating results", "drop zone", "visible", "hidden", "cleanshot", "record", "demo", "share"], tab: .general, section: ""
        ),
        SettingEntry(
            id: "general.main.pauseAutomaticOptimisations", keys: ["pauseAutomaticOptimisations"],
            title: "暂停自动优化",
            subtitle: "",
            keywords: ["resume", "stop", "disable", "snooze", "watcher", "watched folders", "clipboard", "nothing happens", "not working", "temporarily", "off"], tab: .general, section: ""
        ),
        SettingEntry(
            id: "general.workingdirectory.workdir", keys: ["workdir"],
            title: "工作目录路径",
            subtitle: "",
            keywords: ["workdir", "folder", "cache", "temp", "temporary", "backups", "scratch", "disk space", "location", "move", "reset"], tab: .general, section: "工作目录"
        ),
        SettingEntry(
            id: "keys.triggerkeys.keyComboModifiers", keys: ["keyComboModifiers"],
            title: "触发键",
            subtitle: "",
            keywords: ["modifier", "modifiers", "hotkey", "shortcut", "control", "shift", "option", "command", "ctrl", "hold", "combo", "global"], tab: .keys, section: "触发键"
        ),
        SettingEntry(
            id: "keys.actionkeys.enabledKeys", keys: ["enabledKeys"],
            title: "操作按键",
            subtitle: "",
            keywords: [
                "hotkey",
                "shortcut",
                "downscale",
                "quicklook",
                "rename",
                "restore original",
                "pause",
                "escape",
                "dismiss",
                "clear all",
                "bring back",
                "speed up",
                "aggressive",
                "optimise aggressively",
                "optimise clipboard",
                "stop",
                "paste",
                "keycap",
            ], tab: .keys, section: "操作按键"
        ),
        SettingEntry(
            id: "keys.resizekeys.quickResizeKeys", keys: ["quickResizeKeys"],
            title: "调整尺寸按键",
            subtitle: "",
            keywords: ["downscale", "percent", "percentage", "10%", "20%", "90%", "tens", "number row", "hotkey", "shortcut", "scale", "shrink", "smaller", "trigger", "hold", "quick"], tab: .keys, section: "调整尺寸按键"
        ),
        SettingEntry(
            id: "floating.main.floatingResultActions", keys: ["floatingResultActions"],
            title: "操作按钮",
            subtitle: "",
            keywords: ["floating result", "grid", "icons", "share", "quicklook", "customise", "reorder", "remove", "add", "toolbar", "send securely", "aggressive", "downscale"], tab: .floating, section: ""
        ),
        SettingEntry(
            id: "floating.main.compactResultActions", keys: ["compactResultActions"],
            title: "侧边操作",
            subtitle: "",
            keywords: ["compact result", "icons", "buttons", "row", "customise", "add", "remove", "quicklook", "share", "crop", "show in finder", "save as"], tab: .floating, section: ""
        ),
        SettingEntry(
            id: "images.watchpaths.dirsHideFloatingResult", keys: [],
            title: "显示结果浮窗",
            subtitle: "优化此文件夹中的文件时显示浮动缩略图和进度",
            keywords: ["watched", "silent", "quiet", "hide", "no popup", "background", "checkbox", "column", "notification", "per directory"], tab: .images, section: "监控路径"
        ),
        SettingEntry(
            id: "presetZones.presetzones.presetZones", keys: [],
            title: "预设区",
            subtitle: "点击预设区可分配或新建流程。将文件拖到预设区即可运行流程",
            keywords: ["drop target", "quadrant", "corner", "control key", "image", "video", "audio", "pdf", "automation"], tab: .presetZones, section: "预设区"
        ),

    ]

    static let all = rows.filter { warpDropAvailable || $0.id != "general.main.defaultLinkExpiration" }

    static let byID: [String: SettingEntry] = Dictionary(all.map { ($0.id, $0) }, uniquingKeysWith: { a, _ in a })

    /// Words a query carries and a settings row does not. Dropped rather than down-weighted, because
    /// `requireAll` is the problem: someone types "replacing the original video", the row that answers
    /// it has no "the" anywhere, and requiring the word throws the answer away and keeps whichever
    /// rows happen to have a full sentence for a subtitle.
    ///
    /// A fixed list rather than one read off the index. In 125 rows "the" looks rare enough to matter
    /// and it never does, so frequency is the wrong instrument here.
    static let stopWords: Set = [
        "an", "and", "any", "are", "as", "at", "be", "but", "by", "can", "do", "does", "for", "from",
        "get", "has", "have", "how", "if", "in", "into", "is", "it", "its", "me", "my", "no", "not",
        "of", "on", "or", "so", "some", "that", "the", "their", "them", "then", "there", "these",
        "they", "this", "to", "was", "what", "when", "where", "which", "why", "will", "with", "would",
        "you", "your",
    ]

    /// The title an anchored control is named by, for rows that write exactly one key and whose id
    /// no other row shares.
    static func accessibilityTitle(for id: String) -> String? {
        accessibilityTitles[id]
    }

    /// Split into lowercase words. Shared by the index and the query so both are cut the same way.
    static func words(_ text: String) -> [String] {
        text.lowercased().split(whereSeparator: { !$0.isLetter && !$0.isNumber }).map(String.init)
    }

    /// How well a query word matches an indexed word, 0 when it does not.
    ///
    /// Graded rather than yes/no, because the rungs have to outrank each other: typing "send" must put
    /// the row called "Send securely" above a row that merely mentions "sender" in a keyword.
    ///
    /// The prefix rung carries the field while you are still typing, and it has no minimum length on
    /// purpose. An earlier version needed four characters before it would look at a prefix at all,
    /// which meant "sen" found nothing and the field looked broken until the fourth keystroke.
    static func wordScore(_ query: String, _ indexed: String) -> Double {
        if query == indexed {
            return 1
        }
        if indexed.hasPrefix(query) {
            return 0.9
        }
        // Neither is a prefix of the other, and they can still be the same word: "replacing" and
        // "replace" part ways at the seventh letter. A strict prefix test scores that pair zero, which
        // is exactly how a question about Clop "replacing" the original missed the row whose keyword is
        // "replace". Scored by how much of the longer word the stem accounts for, so a real inflection
        // lands near a prefix hit and "compression" against "compatibility" lands nowhere.
        let stem = sharedPrefixLength(query, indexed)
        let ratio = Double(stem) / Double(max(query.count, indexed.count))
        if stem >= 4, ratio >= 0.5 {
            return 0.85 * ratio
        }
        if query.count >= 4, indexed.contains(query) {
            return 0.5
        }
        return 0
    }

    /// Is `query` a subsequence of `text`, and how tightly packed? nil when it is not in there at all.
    ///
    /// The fzf trick, and the net for typos and abbreviations: "clipbord" and "metdata" are nobody's
    /// word, and both are one dropped letter from a row that exists. Runs of adjacent letters and
    /// letters landing on a word boundary score higher, which is what keeps the loose matches off rows
    /// that merely happen to contain the letters somewhere.
    ///
    /// Four characters minimum: below that the letters of a query are scattered through most of the
    /// index and the score means nothing.
    static func subsequenceScore(_ query: String, _ text: String) -> Double? {
        guard query.count >= 4, text.count >= query.count else { return nil }
        let q = Array(query), t = Array(text)
        var score = 0, streak = 0, ti = 0

        for ch in q {
            var found = false
            while ti < t.count {
                if t[ti] == ch {
                    let atWordStart = ti == 0 || !(t[ti - 1].isLetter || t[ti - 1].isNumber)
                    streak += 1
                    score += 1 + streak * 3 + (atWordStart ? 6 : 0)
                    ti += 1
                    found = true
                    break
                }
                streak = 0
                ti += 1
            }
            guard found else { return nil }
        }

        // Against a perfect contiguous run starting at a word boundary, so a long subtitle that happens
        // to contain the letters cannot outscore a short title that spells them out.
        let perfect = q.indices.reduce(6) { $0 + 1 + ($1 + 1) * 3 }
        return min(1, Double(score) / Double(perfect))
    }

    /// The best any field of `entry` does with one query word.
    static func tokenScore(_ token: String, in entry: SettingEntry) -> Double {
        var best = 0.0
        for field in entry.searchFields {
            for word in field.words {
                let score = wordScore(token, word)
                guard score > 0 else { continue }
                best = max(best, field.weight * score)
            }
        }
        guard best == 0 else { return best }

        // Only once no whole word matched. Held below the weakest whole-word rung deliberately: a
        // subsequence hit is a guess, and it must never push a row that really carries the word down.
        for field in entry.searchTexts {
            guard let score = subsequenceScore(token, field.text) else { continue }
            best = max(best, field.weight * score * 0.4)
        }
        return best
    }

    /// Rows matching the query, best first.
    ///
    /// `requireAll` is what separates the two callers. The Settings field passes true, because someone
    /// typing two words expects both to count. An agent hands over a whole sentence full of words no
    /// row carries, so `MCPSettingsBridge.matches` passes false and leans on the scoring instead.
    static func rank(_ query: String, requireAll: Bool, limit: Int = 25) -> [SettingEntry] {
        var tokens = Array(Set(words(query).filter { $0.count > 1 && !stopWords.contains($0) }))
        // Unless the query is nothing but function words, in which case they are all there is to go on.
        if tokens.isEmpty {
            tokens = Array(Set(words(query).filter { $0.count > 1 }))
        }
        guard !tokens.isEmpty else { return [] }

        // Scored once per row and word, then reused for the weighting below. The weighting needs to
        // know how many rows each word hits, and running a fuzzy matcher over the whole index twice is
        // the expensive half of a keystroke.
        let scores = all.map { entry in tokens.map { tokenScore($0, in: entry) } }
        let hits = tokens.indices.map { t in scores.reduce(0.0) { $0 + ($1[t] > 0 ? 1 : 0) } }
        // Squared, so the one word that decides the answer dominates the ones every row carries. Plain
        // inverse document frequency damps too gently for a query that is a whole sentence: "the" is in
        // 37 rows and "mp4" is in 5, and a title match on "the" was outscoring the row that actually
        // answers the question.
        let weights = hits.map { pow(Foundation.log((Double(all.count) + 1) / ($0 + 1)) + 0.1, 2) }

        return zip(all, scores).compactMap { entry, rowScores -> (SettingEntry, Double)? in
            var total = 0.0
            var matched = 0
            for (t, score) in rowScores.enumerated() where score > 0 {
                matched += 1
                total += score * weights[t]
            }
            guard matched > 0 else { return nil }
            if requireAll, matched < tokens.count {
                return nil
            }
            return (entry, total)
        }
        .sorted { $0.1 == $1.1 ? $0.0.title < $1.0.title : $0.1 > $1.1 }
        .prefix(limit)
        .map(\.0)
    }

    /// What the Settings search field calls: rows matching every word, best first.
    ///
    /// Falling back to the partial match keeps the field from dead-ending. Someone types a phrase with
    /// one word no row carries and the answer is still one word away, so showing the rows that match
    /// the rest beats "Nothing matches".
    static func search(_ query: String) -> [SettingEntry] {
        let strict = rank(query, requireAll: true)
        return strict.isEmpty ? rank(query, requireAll: false) : strict
    }

    private static let accessibilityTitles: [String: String] = {
        let counts = Dictionary(grouping: all, by: \.id).mapValues(\.count)
        return Dictionary(all.filter { $0.keys.count == 1 && counts[$0.id] == 1 }.map { ($0.id, $0.title) }, uniquingKeysWith: { a, _ in a })
    }()

    private static func sharedPrefixLength(_ a: String, _ b: String) -> Int {
        zip(a, b).prefix { $0 == $1 }.count
    }

}
